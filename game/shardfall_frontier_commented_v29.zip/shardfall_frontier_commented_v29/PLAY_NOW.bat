\
@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    call ".venv\Scripts\python.exe" main.py
    goto :eof
)
py -3 main.py 2>nul
if errorlevel 1 python main.py
