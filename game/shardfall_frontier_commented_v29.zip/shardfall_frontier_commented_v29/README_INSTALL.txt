Shardfall Frontier v29 - Windows Quick Start

Option 1: One-click launch
1. Double-click INSTALL_AND_PLAY.bat
2. Wait while it creates a local virtual environment and installs pygame
3. The game starts automatically

Option 2: Portable run
1. Double-click PLAY_NOW.bat

Option 3: Build a single EXE on your Windows PC
1. Double-click BUILD_EXE_ON_WINDOWS.bat
2. The EXE will be created in the dist folder

Notes
- This package includes a one-click Windows launcher.
- A native EXE installer cannot be built reliably in this environment, so the included batch files are the safest route.
- Saves and settings are written next to the game folder.
