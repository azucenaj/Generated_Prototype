import json
import math
import random
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pygame
from pygame import Vector2

TITLE = 'Shardfall Frontier: Riftfall Arsenal'
FPS = 60
WIDTH, HEIGHT = 1280, 720
WORLD_W, WORLD_H = 3200, 2200
MIN_ZOOM, MAX_ZOOM = 0.65, 1.8
ROOT = Path(__file__).resolve().parent
ASSET_DIR = ROOT / 'assets'
PROFILE_FILE = ROOT / 'profiles.json'
RUN_SAVE_FILE = ROOT / 'run_save.json'
SETTINGS_FILE = ROOT / 'settings.json'

BG = (11, 16, 24)
BG2 = (18, 24, 36)
PANEL = (18, 26, 40)
PANEL2 = (28, 38, 56)
TEXT = (237, 244, 255)
MUTED = (155, 175, 195)
CYAN = (76, 228, 255)
RED = (255, 102, 114)
GREEN = (110, 220, 145)
YELLOW = (255, 214, 98)
PURPLE = (169, 132, 255)
ORANGE = (255, 163, 82)
WHITE = (255, 255, 255)

GAME_MODES = {
    'Frontier': {'enemy_mult': 1.0, 'shop_mult': 1.0, 'event_rate': 1.0, 'node_mult': 1.0},
    'Rush': {'enemy_mult': 1.25, 'shop_mult': 1.12, 'event_rate': 1.25, 'node_mult': 0.85},
    'Prospector': {'enemy_mult': 0.95, 'shop_mult': 0.95, 'event_rate': 1.0, 'node_mult': 1.55},
    'Gauntlet': {'enemy_mult': 1.35, 'shop_mult': 1.18, 'event_rate': 1.35, 'node_mult': 0.9},
}
MODE_LIST = list(GAME_MODES.keys())

SHOP_DEFS = [
    ('Pulse Core', 44, '+5 damage.', 'damage'),
    ('Scatter Array', 62, '+1 shot, +spread.', 'scatter'),
    ('Turbo Feed', 48, 'Shoot faster.', 'firerate'),
    ('Hull Plating', 50, '+20 max hp, heal 20.', 'hull'),
    ('Shunt Drive', 46, '+30 speed.', 'speed'),
    ('Orbital Disk', 72, 'Adds 1 rotating disk.', 'disk'),
    ('Disk Torque', 64, 'Disk speed and damage up.', 'disk_torque'),
    ('Blink Rig', 70, 'Enables blink movement.', 'blink'),
    ('Shock Ram', 76, 'Dash emits a shockwave.', 'shock'),
    ('Relic Cache', 60, 'Gain 1 stored relic charge.', 'relic'),
    ('Jet Harness', 84, 'Unlocks short jet burst.', 'jet'),
    ('Scatter Shotgun', 78, 'Sets right-click weapon to shotgun and boosts it.', 'weapon_shotgun'),
    ('Beam Emitter', 82, 'Sets right-click weapon to laser beam and boosts it.', 'weapon_laser'),
    ('Rocket Rack', 88, 'Sets right-click weapon to rockets and boosts it.', 'weapon_rocket'),
    ('Nano Regen', 74, 'Passive regen improves.', 'regen'),
    ('Bomb Satchel', 68, 'Gain 1 battlefield bomb.', 'bomb'),
    ('Shield Cell', 66, 'Gain 1 shield layer.', 'shield'),
    ('Overclock', 72, 'Gain rapid-fire buff this run.', 'buff_rapid'),
    ('Rage Serum', 72, 'Gain damage buff this run.', 'buff_rage'),
    ('Blast Mine', 70, 'Gain 2 bombs.', 'bomb'),
    ('Relic Prism', 76, 'Gain a relic and boost drops.', 'relic'),
    ('Aegis Mesh', 78, 'Gain 2 shield layers.', 'shield'),
]

FREEBIES = [
    ('Nano Patch', 'Heal 30 hp.', 'heal'),
    ('Ore Pulse', '+35 ore.', 'ore'),
    ('Adrenal Surge', '+25 speed this run.', 'speed'),
    ('Sharpen', '+3 damage.', 'damage'),
    ('Capacitor', '-8% fire delay.', 'firerate'),
]


# Restricts a value to a minimum and maximum range.
def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# Splits long UI strings into lines that fit inside a pixel width.
def wrap_text(text: str, font: pygame.font.Font, max_width: int) -> List[str]:
    words = text.split()
    lines: List[str] = []
    current = ''
    for word in words:
        test = word if not current else f'{current} {word}'
        if font.size(test)[0] <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines or ['']


# Draws wrapped text inside a target rectangle.
def draw_wrapped_text(surf: pygame.Surface, text: str, font: pygame.font.Font, color: Tuple[int, int, int], rect: pygame.Rect, line_gap: int = 4):
    y = rect.y
    for line in wrap_text(text, font, rect.width):
        img = font.render(line, True, color)
        surf.blit(img, (rect.x, y))
        y += img.get_height() + line_gap


def point_line_distance(point: Vector2, a: Vector2, b: Vector2) -> float:
    ab = b - a
    if ab.length_squared() == 0:
        return point.distance_to(a)
    t = max(0.0, min(1.0, (point - a).dot(ab) / ab.length_squared()))
    proj = a + ab * t
    return point.distance_to(proj)


# Loads and uniformly scales a square image from the assets folder.
def load_image(name: str, scale: int) -> pygame.Surface:
    surf = pygame.image.load((ASSET_DIR / name).as_posix()).convert_alpha()
    return pygame.transform.smoothscale(surf, (scale, scale))


# Multiplies a surface by a tint color for simple recoloring.
def tint_surface(surface: pygame.Surface, tint: Tuple[int, int, int]) -> pygame.Surface:
    tinted = surface.copy()
    tinted.fill((*tint, 255), special_flags=pygame.BLEND_RGBA_MULT)
    return tinted

# Loads an image at its original size with alpha preserved.
def load_raw_image(name: str) -> pygame.Surface:
    return pygame.image.load((ASSET_DIR / name).as_posix()).convert_alpha()

# Removes light checkerboard backgrounds from imported sprite strips.
def remove_checker_bg(surface: pygame.Surface) -> pygame.Surface:
    surf = surface.convert_alpha()
    arr = pygame.surfarray.pixels3d(surf)
    alpha = pygame.surfarray.pixels_alpha(surf)
    import numpy as np
    mask = ((np.abs(arr[:,:,0].astype(np.int16) - arr[:,:,1].astype(np.int16)) < 8)
            & (np.abs(arr[:,:,1].astype(np.int16) - arr[:,:,2].astype(np.int16)) < 8)
            & (arr[:,:,0] > 160) & (arr[:,:,0] < 224))
    alpha[mask] = 0
    del arr, alpha
    return surf

def sanitize_sprite(surface: pygame.Surface) -> pygame.Surface:
    surf = remove_checker_bg(surface)
    arr = pygame.surfarray.pixels3d(surf)
    alpha = pygame.surfarray.pixels_alpha(surf)
    h, w = alpha.shape[1], alpha.shape[0]
    import collections, numpy as np
    q = collections.deque()
    seen = np.zeros((w, h), dtype=bool)

    def border_bad(x, y):
        if alpha[x, y] == 0:
            return False
        r, g, b = arr[x, y]
        return max(r, g, b) < 48 or (abs(int(r)-int(g)) < 8 and abs(int(g)-int(b)) < 8 and 150 < r < 230)

    for x in range(w):
        for y in (0, h-1):
            if border_bad(x, y) and not seen[x, y]:
                q.append((x, y)); seen[x, y] = True
    for y in range(h):
        for x in (0, w-1):
            if border_bad(x, y) and not seen[x, y]:
                q.append((x, y)); seen[x, y] = True

    while q:
        x, y = q.popleft()
        alpha[x, y] = 0
        for nx, ny in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
            if 0 <= nx < w and 0 <= ny < h and not seen[nx, ny]:
                if border_bad(nx, ny):
                    seen[nx, ny] = True
                    q.append((nx, ny))
    del arr, alpha
    return surf


def trim_transparent(surface: pygame.Surface, pad: int = 2) -> pygame.Surface:
    bounds = surface.get_bounding_rect()
    if bounds.width <= 0 or bounds.height <= 0:
        return surface
    bx = max(0, bounds.x - pad)
    by = max(0, bounds.y - pad)
    bw = min(surface.get_width() - bx, bounds.width + pad * 2)
    bh = min(surface.get_height() - by, bounds.height + pad * 2)
    return surface.subsurface(pygame.Rect(bx, by, bw, bh)).copy()

# Crops and scales a region from a sprite sheet.
def crop_sheet(surface: pygame.Surface, rect: Tuple[int, int, int, int], out_h: int = 64, checker_transparent: bool = False) -> pygame.Surface:
    sx, sy = surface.get_size()
    a, b, c, d = rect
    # Accept either (x, y, w, h) or (x1, y1, x2, y2), then clamp safely.
    if a < c and b < d and (a + c > sx or b + d > sy):
        x, y, w, h = a, b, c - a, d - b
    else:
        x, y, w, h = a, b, c, d
    x = max(0, min(int(x), sx - 1))
    y = max(0, min(int(y), sy - 1))
    w = max(1, min(int(w), sx - x))
    h = max(1, min(int(h), sy - y))
    frame = surface.subsurface(pygame.Rect(x, y, w, h)).copy()
    if checker_transparent:
        frame = sanitize_sprite(frame)
    bounds = frame.get_bounding_rect()
    if bounds.width > 0 and bounds.height > 0:
        frame = frame.subsurface(bounds).copy()
    ratio = out_h / max(1, frame.get_height())
    return pygame.transform.smoothscale(frame, (max(8, int(frame.get_width() * ratio)), out_h))


# Safe crop wrapper that returns a blank surface if the crop is invalid.
def crop_safe(surface: pygame.Surface, rect: Tuple[int, int, int, int], out_h: int = 64, checker_transparent: bool = False) -> pygame.Surface:
    frame = crop_sheet(surface, rect, out_h, checker_transparent)
    if frame.get_width() < 4 or frame.get_height() < 4:
        blank = pygame.Surface((out_h, out_h), pygame.SRCALPHA)
        return blank
    return frame


# Slices a horizontal strip into evenly spaced animation frames.
def slice_strip(surface: pygame.Surface, rect: Tuple[int, int, int, int], count: int, out_h: int = 56, checker_transparent: bool = False) -> List[pygame.Surface]:
    x1, y1, x2, y2 = rect
    width = max(1, x2 - x1)
    tile_w = width / max(1, count)
    frames: List[pygame.Surface] = []
    for i in range(count):
        left = int(x1 + i * tile_w)
        right = int(x1 + (i + 1) * tile_w)
        frames.append(crop_safe(surface, (left, y1, right, y2), out_h, checker_transparent))
    return frames


# Splits the panorama sheet into four horizontal sky bands.
def slice_background_bands(surface: pygame.Surface) -> List[pygame.Surface]:
    w, h = surface.get_size()
    band_h = h // 4
    return [surface.subsurface(pygame.Rect(0, i * band_h, w, band_h)).copy() for i in range(4)]


# Extracts named player animation frames from manually defined boxes.
def slice_frames(sheet_name: str, boxes: Dict[str, List[Tuple[int, int, int, int]]], out_h: int = 88) -> Dict[str, List[pygame.Surface]]:
    sheet = pygame.image.load((ASSET_DIR / sheet_name).as_posix()).convert_alpha()
    frames: Dict[str, List[pygame.Surface]] = {}
    for state, crops in boxes.items():
        items = []
        for x1, y1, x2, y2 in crops:
            frame = sheet.subsurface(pygame.Rect(x1, y1, x2 - x1, y2 - y1)).copy()
            frame = frame.subsurface(frame.get_bounding_rect()).copy()
            ratio = out_h / max(1, frame.get_height())
            items.append(pygame.transform.smoothscale(frame, (max(8, int(frame.get_width() * ratio)), out_h)))
        frames[state] = items
    return frames


# Function or method implementation.
def transparentize_checker(surface: pygame.Surface) -> pygame.Surface:
    try:
        import numpy as np
    except Exception:
        return surface
    surf = surface.convert_alpha()
    arr = pygame.surfarray.pixels3d(surf)
    alpha = pygame.surfarray.pixels_alpha(surf)
    a = arr.astype('int16')
    mask = (a[:,:,0] > 170) & (a[:,:,1] > 170) & (a[:,:,2] > 170) & (abs(a[:,:,0]-a[:,:,1]) < 12) & (abs(a[:,:,1]-a[:,:,2]) < 12)
    alpha[mask] = 0
    del arr, alpha
    return surf


# Slices one enemy strip into trimmed and scaled frames.
def slice_enemy_sheet(name: str, frame_count: int, out_h: int = 58) -> List[pygame.Surface]:
    sheet = transparentize_checker(load_raw_image(name))
    w, h = sheet.get_size()
    frame_w = w // frame_count
    frames = []
    for i in range(frame_count):
        frame = sheet.subsurface(pygame.Rect(i * frame_w, 0, frame_w, h)).copy()
        frame = trim_transparent(frame)
        ratio = out_h / max(1, frame.get_height())
        frame = pygame.transform.smoothscale(frame, (max(8, int(frame.get_width() * ratio)), out_h))
        frames.append(frame)
    return frames


# Loads all enemy strips into animation frame lists.
def slice_enemy_row(surface: pygame.Surface, row_index: int, frame_count: int, total_rows: int = 10, out_h: int = 58) -> List[pygame.Surface]:
    # Slice one row from the uploaded enemy strips, remove the checker background, then crop tightly.
    w, h = surface.get_size()
    row_h = h // total_rows
    y = row_index * row_h
    frame_w = w / max(1, frame_count)
    frames: List[pygame.Surface] = []
    for i in range(frame_count):
        left = int(i * frame_w)
        right = int((i + 1) * frame_w)
        frame = surface.subsurface(pygame.Rect(left, y, max(1, right - left), row_h)).copy()
        frame = sanitize_sprite(frame)
        frame = trim_transparent(frame, 2)
        ratio = out_h / max(1, frame.get_height())
        frames.append(pygame.transform.smoothscale(frame, (max(8, int(frame.get_width() * ratio)), out_h)))
    return frames

def slice_attack_strip(name: str, frame_count: int, out_h: int) -> List[pygame.Surface]:
    surf = load_raw_image(name)
    w, h = surf.get_size()
    frame_w = w / max(1, frame_count)
    frames: List[pygame.Surface] = []
    for i in range(frame_count):
        left = int(i * frame_w)
        right = int((i + 1) * frame_w)
        frame = surf.subsurface(pygame.Rect(left, 0, max(1, right - left), h)).copy()
        frame = sanitize_sprite(frame)
        frame = trim_transparent(frame, 2)
        ratio = out_h / max(1, frame.get_height())
        frames.append(pygame.transform.smoothscale(frame, (max(8, int(frame.get_width() * ratio)), out_h)))
    return frames


def slice_object_strip(name: str, frame_count: int, out_h: int) -> List[pygame.Surface]:
    surf = load_raw_image(name)
    w, h = surf.get_size()
    frame_w = w / max(1, frame_count)
    frames: List[pygame.Surface] = []
    for i in range(frame_count):
        left = int(i * frame_w)
        right = int((i + 1) * frame_w)
        frame = surf.subsurface(pygame.Rect(left, 0, max(1, right - left), h)).copy()
        frame = sanitize_sprite(frame)
        frame = trim_transparent(frame)
        ratio = out_h / max(1, frame.get_height())
        frames.append(pygame.transform.smoothscale(frame, (max(8, int(frame.get_width() * ratio)), out_h)))
    return frames

def load_clean_image(name: str, out_h: int, remove_bg: bool = True) -> pygame.Surface:
    surf = load_raw_image(name)
    if remove_bg:
        surf = sanitize_sprite(surf)
    surf = trim_transparent(surf, 2)
    ratio = out_h / max(1, surf.get_height())
    return pygame.transform.smoothscale(surf, (max(8, int(surf.get_width() * ratio)), out_h))

def load_ui_sprite(name: str) -> pygame.Surface:
    return load_raw_image(name)

def load_ui_generated(name: str, size: Tuple[int, int]) -> pygame.Surface:
    surf = load_raw_image(name)
    return pygame.transform.smoothscale(surf, size)

def load_weapon_icon(name: str, out_h: int = 28) -> pygame.Surface:
    surf = load_raw_image(name)
    crop = surf.subsurface(pygame.Rect(0, 0, min(120, surf.get_width()//3), surf.get_height())).copy()
    crop = sanitize_sprite(crop)
    bounds = crop.get_bounding_rect()
    if bounds.width > 0 and bounds.height > 0:
        crop = crop.subsurface(bounds).copy()
    ratio = out_h / max(1, crop.get_height())
    return pygame.transform.smoothscale(crop, (max(12, int(crop.get_width() * ratio)), out_h))

def load_enemy_animation_set() -> Dict[str, Dict[str, List[pygame.Surface]]]:
    death_sheet = load_raw_image('space enemy death.png')
    walk_map = {
        'grunt': ('green 1 walk.png', 5, 58),
        'elite': ('green 2 walk.png', 5, 60),
        'grenadier': ('yellow walk.png', 5, 56),
        'spider': ('spider walk.png', 4, 62),
        'brute': ('red 1 walk.png', 5, 58),
        'ufo': ('UFO walk.png', 5, 54),
        'warper': ('warper idle.png', 4, 62),
        'tank': ('red 2 walk.png', 5, 60),
        'soldier': ('red 3 walk.png', 5, 58),
        'shooter': ('blue walk.png', 4, 54),
        'rifleman': ('red mask walk.png', 5, 58),
        'crawler': ('crawler walk 1.png', 4, 62),
        'bomber': ('crawler walk 2.png', 4, 62),
        'boss1': ('boss1 walk.png', 5, 76),
        'boss2': ('boss2 idle.png', 3, 84),
        'boss3': ('final boss.png', 5, 90),
    }
    death_map = {
        'crawler': (1, 6, 58), 'brute': (1, 6, 58), 'shooter': (7, 5, 58), 'soldier': (3, 6, 58),
        'tank': (4, 6, 60), 'ufo': (5, 5, 54), 'elite': (6, 5, 60), 'rifleman': (7, 5, 58),
        'grenadier': (8, 5, 58), 'grunt': (9, 5, 58), 'spider': (8, 5, 58), 'warper': (5, 5, 54),
        'bomber': (1, 6, 58), 'boss1': (1, 6, 58), 'boss2': (5, 5, 54), 'boss3': (1, 6, 58),
    }
    attack_map = {
        'grunt': ('green 1 attack.png', 5, 58),
        'elite': ('green 2 attack.png', 4, 60),
        'grenadier': ('yellow attack.png', 4, 56),
        'brute': ('red 1 attack.png', 5, 58),
        'ufo': ('UFO attack.png', 5, 54),
        'tank': ('red 2 attack.png', 5, 60),
        'soldier': ('red 3 attack.png', 5, 58),
        'shooter': ('blue attack.png', 4, 54),
        'rifleman': ('red mask attack.png', 5, 58),
        'crawler': ('red 1 attack.png', 5, 56),
        'bomber': ('red 1 attack.png', 5, 56),
        'warper': ('warper attack.png', 4, 62),
        'spider': ('yellow attack.png', 4, 56),
        'boss1': ('boss1 attack.png', 5, 76),
        'boss2': ('boss2 idle2.png', 3, 84),
        'boss3': ('boss3 attack.png', 5, 90),
    }
    data = {}
    for kind, (walk_name, walk_count, walk_h) in walk_map.items():
        attack_name, attack_count, attack_h = attack_map[kind]
        death_row, death_count, death_h = death_map[kind]
        entry = {
            'walk': slice_attack_strip(walk_name, walk_count, walk_h),
            'attack': slice_attack_strip(attack_name, attack_count, attack_h),
            'death': slice_enemy_row(death_sheet, death_row, death_count, 10, death_h),
        }
        if kind == 'warper':
            entry['warp'] = slice_attack_strip('warper warping.png', 4, 62)
            entry['reappear'] = slice_attack_strip('warper reappear after warp.png', 4, 62)
        if kind == 'boss2':
            entry['warp'] = [trim_transparent(load_raw_image('boss2 newwarp1.png')), trim_transparent(load_raw_image('boss2 newwarp2.png'))]
            entry['reappear'] = [trim_transparent(load_raw_image('boss2 newwarp2.png')), trim_transparent(load_raw_image('boss2 newwarp1.png'))]
        if kind == 'boss3':
            entry['walk'] = slice_attack_strip('boss3 walk.png', 5, 90)
        data[kind] = entry
    return data



# Handles sound effect and music loading/playback for the game.
class Audio:
    # Audio manager for sound effect and music with runtime volume controls.
    def __init__(self, sfx_volume: float = 0.7, music_volume: float = 0.35):
        self.ok = False
        self.sounds: Dict[str, pygame.mixer.Sound] = {}
        self.base_volumes: Dict[str, float] = {}
        self.sfx_volume = clamp(sfx_volume, 0.0, 1.0)
        self.music_volume = clamp(music_volume, 0.0, 1.0)
        try:
            pygame.mixer.init()
            self.ok = True
        except pygame.error:
            self.ok = False
        if self.ok:
            self._load('laser', 'laser.ogg', 0.25)
            self._load('eat', 'eat.mp3', 0.35)
            self._load('explode', 'explosion.ogg', 0.35)
            self._load('clear', 'clear.ogg', 0.45)
            self._load('rotate', 'rotate.ogg', 0.25)
            self._load('wall', 'wall.mp3', 0.25)
            self._load('weapon_laser', 'laser.wav', 0.55)
            self._load('weapon_shotgun', 'shotgun.wav', 0.65)
            self._load('weapon_rocket', 'rocket.wav', 0.70)
            self._load('weapon_pellet', 'simple_pellet.wav', 0.45)
            self._load('weapon_spread', 'spread.wav', 0.55)
            self._load('weapon_explosion', 'explosion.wav', 0.65)
            self._load('blink_new', 'teleport_blink.wav', 0.60)
            self._load('enemy_worm', '01_worm_beast_bite.wav', 0.60)
            self._load('enemy_trooper', '02_red_trooper_blaster.wav', 0.55)
            self._load('enemy_plasma', '03_plasma_caster.wav', 0.55)
            self._load('enemy_spider', '04_spider_mech_attack.wav', 0.60)
            self._load('enemy_flame', '05_flamethrower_heavy.wav', 0.55)
            self._load('enemy_ufo', '06_ufo_drone_beam.wav', 0.55)
            self._load('enemy_orange', '07_orange_rifle_bug.wav', 0.55)
            self._load('enemy_popgun', '08_green_grunt_popgun.wav', 0.55)
            self._load('enemy_blue', '09_blue_laser_soldier.wav', 0.55)
            self._load('enemy_green', '10_green_blaster_alien.wav', 0.55)
            self.current_music = None
            default_music = ASSET_DIR / 'music.ogg'
            if default_music.exists():
                try:
                    pygame.mixer.music.load(default_music.as_posix())
                    pygame.mixer.music.set_volume(self.music_volume)
                    pygame.mixer.music.play(-1)
                    self.current_music = default_music.name
                except pygame.error:
                    pass
            self.set_sfx_volume(self.sfx_volume)
            self.set_music_volume(self.music_volume)

    def _load(self, key, filename, vol):
        path = ASSET_DIR / filename
        if path.exists():
            try:
                snd = pygame.mixer.Sound(path.as_posix())
                self.base_volumes[key] = vol
                snd.set_volume(vol * self.sfx_volume)
                self.sounds[key] = snd
            except pygame.error:
                pass

    def set_sfx_volume(self, value: float):
        self.sfx_volume = clamp(value, 0.0, 1.0)
        for key, snd in self.sounds.items():
            snd.set_volume(self.base_volumes.get(key, 1.0) * self.sfx_volume)

    def set_music_volume(self, value: float):
        self.music_volume = clamp(value, 0.0, 1.0)
        if self.ok:
            try:
                pygame.mixer.music.set_volume(self.music_volume)
            except pygame.error:
                pass

    def play_music_track(self, filename: str):
        if not self.ok:
            return
        path = ASSET_DIR / filename
        if not path.exists() or self.current_music == filename:
            return
        try:
            pygame.mixer.music.load(path.as_posix())
            pygame.mixer.music.set_volume(self.music_volume)
            pygame.mixer.music.play(-1)
            self.current_music = filename
        except pygame.error:
            pass

    def play(self, key):
        snd = self.sounds.get(key)
        if snd:
            snd.play()


@dataclass
# Small floating text labels used for feedback like damage and pickups.
class FloatText:
    text: str
    pos: Vector2
    color: Tuple[int, int, int]
    ttl: float = 0.9

    # Function or method implementation.
    def update(self, dt):
        self.ttl -= dt
        self.pos.y -= 28 * dt


@dataclass
# Collectible world item such as ore, relic, heal, or temporary buff.
class Pickup:
    pos: Vector2
    kind: str
    value: int
    ttl: float = 15.0


# Timed modifier applied to the player during a run.
class TemporaryBuff:
    # Function or method implementation.
    def __init__(self, kind: str, ttl: float):
        self.kind = kind
        self.ttl = ttl

# Smooth-follow camera with zoom, shake, and coordinate transforms.
class Camera:
    # Function or method implementation.
    def __init__(self):
        self.pos = Vector2(WORLD_W/2, WORLD_H/2)
        self.shake = 0.0
        self.offset = Vector2()
        self.zoom = 1.0

    # Function or method implementation.
    def update(self, target: Vector2):
        self.pos += (target - self.pos) * 0.08
        if self.shake > 0:
            self.shake *= 0.88
            self.offset = Vector2(random.uniform(-self.shake, self.shake), random.uniform(-self.shake, self.shake))
        else:
            self.offset.update(0, 0)

    # Function or method implementation.
    def change_zoom(self, amount: float):
        self.zoom = clamp(self.zoom + amount, MIN_ZOOM, MAX_ZOOM)

    # Function or method implementation.
    def world_to_screen(self, pos: Vector2) -> Vector2:
        return (pos - self.pos) * self.zoom + Vector2(WIDTH/2, HEIGHT/2) + self.offset

    # Function or method implementation.
    def screen_to_world(self, pos: Tuple[int, int]) -> Vector2:
        return (Vector2(pos) - Vector2(WIDTH/2, HEIGHT/2) - self.offset) / self.zoom + self.pos

    # Function or method implementation.
    def scale_value(self, v: float) -> int:
        return max(1, int(v * self.zoom))


# Projectile fired by the player or enemies.
class Bullet:
    # Function or method implementation.
    def __init__(self, pos, vel, damage, owner, radius=5, color=CYAN, pierce=0):
        self.pos = Vector2(pos)
        self.vel = Vector2(vel)
        self.damage = damage
        self.owner = owner
        self.radius = radius
        self.color = color
        self.life = 2.3
        self.pierce = pierce
        self.alive = True

    # Function or method implementation.
    def update(self, dt):
        self.pos += self.vel * dt
        self.life -= dt
        if self.life <= 0 or self.pos.x < -120 or self.pos.y < -120 or self.pos.x > WORLD_W + 120 or self.pos.y > WORLD_H + 120:
            self.alive = False


class LaserBeam:
    # Short-lived beam visual for the alternate laser weapon.
    def __init__(self, start, end, width, color, ttl=0.12):
        self.start = Vector2(start)
        self.end = Vector2(end)
        self.width = width
        self.color = color
        self.ttl = ttl

    def update(self, dt):
        self.ttl -= dt
        return self.ttl > 0


# Rotating disk companion that damages nearby enemies.
class OrbitalDisk:
    # Function or method implementation.
    def __init__(self, owner, index, total):
        self.owner = owner
        self.index = index
        self.total = total
        self.angle = (index / max(1, total)) * math.tau
        self.hit_cd = 0.0

    # Function or method implementation.
    def update(self, dt, game):
        self.angle += self.owner.disk_speed * dt
        self.hit_cd -= dt
        pos = self.position()
        if self.hit_cd <= 0:
            for enemy in game.enemies:
                if enemy.alive and enemy.pos.distance_to(pos) < enemy.radius + 18:
                    enemy.take_hit(self.owner.disk_damage, game, pos)
                    self.hit_cd = 0.1
                    game.audio.play('blink_new')
                    break

    # Function or method implementation.
    def position(self):
        return self.owner.pos + Vector2(math.cos(self.angle), math.sin(self.angle)) * self.owner.disk_radius


# Circular collision object that blocks movement and bullets.
class Obstacle:
    # Function or method implementation.
    def __init__(self, pos, radius):
        self.pos = Vector2(pos)
        self.radius = radius


# Non-colliding world prop used to make the environment feel richer.
class Decoration:
    # Function or method implementation.
    def __init__(self, pos, key, scale=1.0, bob=0.0):
        self.pos = Vector2(pos)
        self.key = key
        self.scale = scale
        self.bob = bob


# Breakable resource node that drops ore when destroyed.
class OreNode:
    # Function or method implementation.
    def __init__(self, pos, tier=1):
        self.pos = Vector2(pos)
        self.radius = 20 + tier * 6
        self.hp = 38 + tier * 22
        self.tier = tier
        self.spin = random.random() * math.tau
        self.alive = True

    # Function or method implementation.
    def hit(self, damage):
        self.hp -= damage
        if self.hp <= 0:
            self.alive = False
            return 10 + self.tier * 8
        return 0



# Breakable container that spawns healing or buff pickups.
class LootPot:
    # Function or method implementation.
    def __init__(self, pos, kind='heal'):
        self.pos = Vector2(pos)
        self.kind = kind
        self.radius = 18
        self.hp = 16 if kind == 'heal' else 18
        self.alive = True
        self.phase = random.random() * math.tau

    # Function or method implementation.
    def hit(self, damage, game):
        self.hp -= damage
        if self.hp <= 0 and self.alive:
            self.alive = False
            if self.kind == 'heal':
                game.pickups.append(Pickup(self.pos.copy(), 'heal', random.randint(18, 32), 18.0))
                if random.random() < 0.3:
                    game.pickups.append(Pickup(self.pos + Vector2(14, -10), 'shield', 1, 18.0))
            else:
                game.pickups.append(Pickup(self.pos.copy(), random.choice(['rapid','rage','haste','magnet']), 1, 18.0))
                if random.random() < 0.45:
                    game.pickups.append(Pickup(self.pos + Vector2(-12, 10), 'ore', random.randint(10, 25), 18.0))
            for _ in range(10):
                game.particles.append(Particle(self.pos, Vector2(random.uniform(-120, 120), random.uniform(-120, 120)), CYAN if self.kind == 'buff' else GREEN, 4, 0.5))
            game.audio.play('clear')
            return True
        return False

# Generic enemy actor with behavior selected by kind.
class Enemy:
    # Function or method implementation.
    def __init__(self, pos, kind, wave):
        self.pos = Vector2(pos)
        self.vel = Vector2()
        self.kind = kind
        self.wave = wave
        self.alive = True
        self.flash = 0.0
        self.attack_cd = random.uniform(0.3, 1.2)
        self.teleport_cd = random.uniform(2.0, 4.0)
        self.arm_timer = random.uniform(1.1, 2.2)
        self.rage = 0.0
        self.anim_time = random.random() * 2.0
        self.phase = random.random() * math.tau
        self.shoot_range = 360
        self.attack_anim = 0.0
        self.explode_on_death = False
        self.warp_anim = 0.0
        self.reappear_anim = 0.0
        self.sprite_kind = kind
        if kind == 'crawler':
            self.radius = 20
            self.speed = 100 + wave * 5
            self.hp = 32 + wave * 8
            self.damage = 14 + wave // 2
            self.reward = 16 + wave * 2
        elif kind == 'brute':
            self.radius = 22
            self.speed = 92 + wave * 4
            self.hp = 44 + wave * 10
            self.damage = 16 + wave // 2
            self.reward = 22 + wave * 3
        elif kind == 'shooter':
            self.radius = 18
            self.speed = 110 + wave * 4
            self.hp = 26 + wave * 6
            self.damage = 12 + wave // 2
            self.reward = 20 + wave * 2
            self.shoot_range = 420
        elif kind == 'spider':
            self.radius = 17
            self.speed = 178 + wave * 8
            self.hp = 22 + wave * 6
            self.damage = 13 + wave // 2
            self.reward = 19 + wave * 2
        elif kind == 'tank':
            self.radius = 24
            self.speed = 82 + wave * 4
            self.hp = 52 + wave * 12
            self.damage = 20 + wave
            self.reward = 28 + wave * 3
            self.shoot_range = 300
        elif kind == 'ufo':
            self.radius = 18
            self.speed = 120 + wave * 5
            self.hp = 24 + wave * 7
            self.damage = 12 + wave // 2
            self.reward = 22 + wave * 2
            self.shoot_range = 450
        elif kind == 'soldier':
            self.radius = 16
            self.speed = 150 + wave * 7
            self.hp = 20 + wave * 5
            self.damage = 11 + wave // 2
            self.reward = 17 + wave * 2
        elif kind == 'rifleman':
            self.radius = 16
            self.speed = 138 + wave * 6
            self.hp = 22 + wave * 6
            self.damage = 12 + wave // 2
            self.reward = 20 + wave * 2
            self.shoot_range = 470
        elif kind == 'bomber':
            self.radius = 18
            self.speed = 210 + wave * 7
            self.hp = 20 + wave * 5
            self.damage = 24 + wave
            self.reward = 24 + wave * 3
            self.arm_timer = random.uniform(0.9, 1.5)
            self.explode_on_death = True
            self.sprite_kind = 'spider'
        elif kind == 'warper':
            self.radius = 17
            self.speed = 132 + wave * 6
            self.hp = 28 + wave * 7
            self.damage = 14 + wave // 2
            self.reward = 24 + wave * 2
            self.teleport_cd = random.uniform(1.5, 2.8)
            self.sprite_kind = 'ufo'
        elif kind == 'grenadier':
            self.radius = 18
            self.speed = 110 + wave * 4
            self.hp = 30 + wave * 7
            self.damage = 16 + wave // 2
            self.reward = 24 + wave * 2
            self.shoot_range = 420
            self.sprite_kind = 'tank'
        elif kind == 'elite':
            self.radius = 22
            self.speed = 145 + wave * 5
            self.hp = 72 + wave * 14
            self.damage = 20 + wave
            self.reward = 34 + wave * 4
            self.shoot_range = 520
            self.teleport_cd = random.uniform(2.5, 4.0)
            self.sprite_kind = 'brute'
        else:  # grunt
            self.radius = 16
            self.speed = 132 + wave * 6
            self.hp = 24 + wave * 6
            self.damage = 12 + wave // 2
            self.reward = 18 + wave * 2

    # Function or method implementation.
    def take_hit(self, damage, game, pos=None):
        self.hp -= damage
        self.flash = 0.15
        hit_pos = self.pos if pos is None else pos
        game.float_texts.append(FloatText(str(int(damage)), hit_pos.copy(), YELLOW if getattr(self, 'is_boss', False) else ORANGE))
        if getattr(self, 'is_boss', False):
            game.camera.shake = max(game.camera.shake, 5)
        for _ in range(3 if not getattr(self, 'is_boss', False) else 6):
            game.particles.append(Particle(hit_pos, Vector2(random.uniform(-80, 80), random.uniform(-80, 80)), ORANGE, 3, 0.22))
        if self.hp <= 0 and self.alive:
            self.alive = False
            game.spawn_pickups(self.pos if pos is None else pos, self.reward)
            if self.explode_on_death:
                game.explosions.append(Explosion(self.pos.copy(), 92, self.damage, 0.35))
            for _ in range(10):
                game.particles.append(Particle(self.pos, Vector2(random.uniform(-120, 120), random.uniform(-120, 120)), RED, 4, 0.35))
            game.audio.play('explode')
            game.player.combo += 1
            game.player.combo_timer = 2.0
            game.combo_glow = max(game.combo_glow, 0.3)
            return True
        return False

    # Function or method implementation.
    def play_attack_sound(self, game):
        key_map = {'crawler': 'enemy_worm', 'bomber': 'enemy_worm', 'brute': 'enemy_trooper', 'shooter': 'enemy_plasma',
                   'spider': 'enemy_spider', 'tank': 'enemy_flame', 'ufo': 'enemy_ufo', 'soldier': 'enemy_blue',
                   'rifleman': 'enemy_orange', 'grenadier': 'enemy_orange', 'grunt': 'enemy_popgun', 'warper': 'enemy_ufo', 'elite': 'enemy_green'}
        game.audio.play(key_map.get(self.kind, 'enemy_popgun'))

    def update(self, dt, game):
        self.flash = max(0.0, self.flash - dt)
        self.attack_anim = max(0.0, self.attack_anim - dt)
        self.attack_cd -= dt
        self.teleport_cd -= dt
        self.anim_time += dt
        self.phase += dt
        target = game.player.pos - self.pos
        dist = max(1, target.length())
        direction = target / dist

        if self.attack_anim > 0:
            self.vel *= 0.12

        if self.kind in ('shooter', 'rifleman', 'ufo', 'grenadier'):
            hold_range = self.shoot_range * (0.84 if self.kind == 'grenadier' else 0.78)
            if self.attack_anim <= 0:
                if dist < hold_range * 0.72:
                    self.vel = -direction * self.speed * 0.45
                elif dist > hold_range:
                    self.vel = direction * self.speed * 0.85
                else:
                    side = Vector2(-direction.y, direction.x) * math.sin(self.phase * 2.2)
                    self.vel = side.normalize() * self.speed * 0.6 if side.length_squared() > 0 else Vector2()
            if self.attack_cd <= 0 and dist < self.shoot_range:
                self.vel *= 0.04
                self.attack_anim = 0.38
                self.attack_cd = 0.95 if self.kind != 'rifleman' else 0.72
                shot_speed = 320 if self.kind == 'grenadier' else 380 + self.wave * 2
                shot = Bullet(self.pos, direction * shot_speed, self.damage, 'enemy', 5 if self.kind != 'grenadier' else 7, ORANGE if self.kind == 'grenadier' else RED)
                if self.kind == 'grenadier':
                    shot.explosive = True
                    shot.explosion_radius = 74 + self.wave // 2
                shot.sprite_key = 'plasma' if self.kind in ('shooter', 'ufo', 'warper') else ('rapid' if self.kind in ('soldier','rifleman','grunt','elite') else ('missile' if self.kind in ('tank','grenadier') else 'pulse'))
                game.enemy_bullets.append(shot)
                self.play_attack_sound(game)
        elif self.kind == 'bomber':
            self.vel = direction * self.speed
            self.arm_timer -= dt
            if dist < 130 or self.arm_timer <= 0:
                self.alive = False
                game.explosions.append(Explosion(self.pos.copy(), 108, self.damage, 0.4))
                game.audio.play('weapon_explosion')
        elif self.kind == 'warper':
            self.vel = direction * self.speed if self.attack_anim <= 0 else self.vel * 0.1
            self.warp_anim = max(0.0, self.warp_anim - dt)
            self.reappear_anim = max(0.0, self.reappear_anim - dt)
            if self.teleport_cd <= 0 and dist > 120 and self.warp_anim <= 0 and self.reappear_anim <= 0:
                self.teleport_cd = random.uniform(1.5, 2.7)
                self.warp_anim = 0.26
                self.pos = game.random_spawn_point(min_dist=180, max_dist=520)
                self.reappear_anim = 0.26
                for _ in range(8):
                    game.particles.append(Particle(self.pos, Vector2(random.uniform(-100,100), random.uniform(-100,100)), PURPLE, 4, 0.4))
            if dist < self.radius + game.player.radius + 10 and self.attack_cd <= 0:
                self.attack_cd = 0.7
                self.attack_anim = 0.34
                game.player.hit(self.damage, game)
                self.play_attack_sound(game)
        elif self.kind == 'elite':
            if self.attack_anim <= 0:
                desired = direction if dist > 240 else -direction * 0.15
                side = Vector2(-direction.y, direction.x) * math.sin(self.phase * 2.8) * 0.55
                move = desired + side
                self.vel = move.normalize() * self.speed if move.length_squared() > 0 else Vector2()
            else:
                self.vel *= 0.08
            if self.teleport_cd <= 0:
                self.teleport_cd = random.uniform(2.6, 4.1)
                self.pos = game.random_spawn_point(min_dist=240, max_dist=680)
            if self.attack_cd <= 0 and dist < 540:
                self.attack_cd = 0.8
                self.attack_anim = 0.40
                for ang in (-18, 0, 18):
                    vec = direction.rotate(ang)
                    shot = Bullet(self.pos, vec * 420, self.damage, 'enemy', 6, RED)
                    shot.sprite_key = 'rapid'
                    game.enemy_bullets.append(shot)
                self.play_attack_sound(game)
        elif self.kind in ('crawler', 'brute', 'soldier', 'grunt', 'spider', 'tank'):
            if self.attack_anim <= 0:
                desired = direction if dist > 190 else -direction * 0.08
                if self.kind in ('spider', 'soldier', 'grunt'):
                    side = Vector2(-direction.y, direction.x) * math.sin(self.phase * 3.0) * 0.3
                    move = desired + side
                    self.vel = move.normalize() * self.speed if move.length_squared() > 0 else Vector2()
                else:
                    self.vel = desired * self.speed
            else:
                self.vel *= 0.08
            if self.kind == 'tank' and self.attack_cd <= 0 and dist < self.shoot_range:
                self.attack_cd = 1.35
                self.attack_anim = 0.42
                shot = Bullet(self.pos, direction * 300, self.damage, 'enemy', 7, ORANGE)
                shot.explosive = True
                shot.explosion_radius = 84
                shot.sprite_key = 'missile'
                game.enemy_bullets.append(shot)
                self.play_attack_sound(game)
            if dist < self.radius + game.player.radius + 8 and self.attack_cd <= 0:
                self.attack_cd = 0.7 if self.kind in ('spider', 'soldier') else 0.95
                self.attack_anim = 0.32
                game.player.hit(self.damage, game)
                self.play_attack_sound(game)

        self.pos += self.vel * dt
        self.pos.x = clamp(self.pos.x, 20, WORLD_W-20)
        self.pos.y = clamp(self.pos.y, 20, WORLD_H-20)



# Larger enemy variant used on milestone waves as a stage boss.
class Boss(Enemy):
    def __init__(self, pos, kind, wave, tier=1):
        super().__init__(pos, kind, wave + tier * 2)
        self.is_boss = True
        self.tier = tier
        self.radius = int(self.radius * 2.0)
        self.hp = int(self.hp * (10 + tier * 1.5))
        self.max_hp = self.hp
        self.damage = int(self.damage * (1.8 + tier * 0.12))
        self.reward = int(self.reward * (6 + tier))
        self.speed = max(70, int(self.speed * 0.9))
        self.name = f'{kind.title()} Boss'

    def take_hit(self, damage, game, pos=None):
        died = super().take_hit(damage, game, pos)
        if died:
            game.float_texts.append(FloatText('Boss Down', self.pos.copy(), YELLOW))
            for _ in range(3):
                game.pickups.append(Pickup(self.pos + Vector2(random.uniform(-24,24), random.uniform(-24,24)), 'relic', 1, 18.0))
        return died

    def update(self, dt, game):
        self.flash = max(0.0, self.flash - dt)
        self.attack_cd -= dt
        self.teleport_cd -= dt
        self.anim_time += dt
        self.phase += dt
        self.warp_anim = max(0.0, getattr(self, 'warp_anim', 0.0) - dt)
        self.reappear_anim = max(0.0, getattr(self, 'reappear_anim', 0.0) - dt)
        target = game.player.pos - self.pos
        dist = max(1, target.length())
        direction = target / dist
        sprite_kind = getattr(self, 'sprite_kind', self.kind)

        if sprite_kind == 'boss2':
            if self.teleport_cd <= 0 and dist > 180 and self.warp_anim <= 0 and self.reappear_anim <= 0:
                self.teleport_cd = random.uniform(1.8, 2.8)
                self.warp_anim = 0.30
                self.pos = game.random_spawn_point(min_dist=240, max_dist=620)
                self.reappear_anim = 0.30
            desired = direction if dist > 300 else -direction * 0.22
            side = Vector2(-direction.y, direction.x) * math.sin(self.phase * 2.0) * 0.75
            move = desired * 0.55 + side
            self.vel = move.normalize() * self.speed if move.length_squared() > 0 else Vector2()
            if self.attack_cd <= 0:
                self.attack_cd = max(0.55, 1.1 - self.tier * 0.04)
                shots = 4 + self.tier
                for i in range(shots):
                    vec = direction.rotate(-34 + (68 / max(1, shots - 1)) * i)
                    b = Bullet(self.pos, vec * (300 + self.tier * 8), self.damage, 'enemy', 7, GREEN)
                    b.sprite_key = 'plasma'
                    game.enemy_bullets.append(b)
        elif sprite_kind == 'boss1':
            desired = direction if dist > 180 else -direction * 0.18
            self.vel = desired * self.speed
            if self.attack_cd <= 0:
                self.attack_cd = max(0.6, 1.0 - self.tier * 0.03)
                for ang in (-24, -12, 0, 12, 24):
                    vec = direction.rotate(ang)
                    b = Bullet(self.pos, vec * (260 + self.tier * 5), self.damage, 'enemy', 7, ORANGE)
                    b.explosive = True
                    b.explosion_radius = 72 + self.tier * 5
                    b.sprite_key = 'missile'
                    game.enemy_bullets.append(b)
                game.explosions.append(Explosion(self.pos, 70 + self.tier * 4, self.damage // 2, 0.22))
        elif sprite_kind == 'boss3':
            desired = direction if dist > 160 else -direction * 0.14
            side = Vector2(-direction.y, direction.x) * math.sin(self.phase * 1.6) * 0.25
            move = desired + side
            self.vel = move.normalize() * self.speed if move.length_squared() > 0 else Vector2()
            if self.attack_cd <= 0:
                self.attack_cd = max(0.7, 1.15 - self.tier * 0.03)
                shots = 8
                for i in range(shots):
                    vec = Vector2(1, 0).rotate(i * (360 / shots))
                    b = Bullet(self.pos, vec * (220 + self.tier * 6), self.damage, 'enemy', 7, CYAN)
                    b.sprite_key = 'pulse'
                    game.enemy_bullets.append(b)
                for _ in range(10):
                    game.particles.append(Particle(self.pos.copy(), Vector2(random.uniform(-80,80), random.uniform(-80,80)), CYAN, 4, 0.6))
        else:
            desired = direction if dist > 260 else -direction * 0.38
            if self.kind in ('ufo', 'rifleman', 'shooter'):
                side = Vector2(-direction.y, direction.x) * math.sin(self.phase * 2.2) * 0.8
                self.vel = (desired * 0.6 + side).normalize() * self.speed
            else:
                self.vel = desired * self.speed
            if self.attack_cd <= 0:
                self.attack_cd = max(0.45, 1.2 - self.tier * 0.05)
                shots = 6 + self.tier
                for i in range(shots):
                    vec = direction.rotate(-28 + (56 / max(1, shots - 1)) * i)
                    game.enemy_bullets.append(Bullet(self.pos, vec * (280 + self.tier * 6), self.damage, 'enemy', 6, RED))
                if self.kind in ('tank', 'brute', 'crawler'):
                    game.explosions.append(Explosion(self.pos, 80 + self.tier * 4, self.damage // 2, 0.28))
        self.pos += self.vel * dt
        self.pos.x = clamp(self.pos.x, 40, WORLD_W - 40)
        self.pos.y = clamp(self.pos.y, 40, WORLD_H - 40)

# Lightweight visual particle used for hits, bursts, and ambiance.

# Lightweight visual particle used for hits, bursts, and ambiance.

# Lightweight visual particle used for hits, bursts, and ambiance.
class Particle:
    # Function or method implementation.
    def __init__(self, pos, vel, color, radius, ttl):
        self.pos = Vector2(pos)
        self.vel = Vector2(vel)
        self.color = color
        self.radius = radius
        self.ttl = ttl
        self.max_ttl = ttl

    # Function or method implementation.
    def update(self, dt):
        self.ttl -= dt
        self.pos += self.vel * dt
        self.vel *= 0.96


# Timed radial damage zone used by bombs, dashes, and effects.
class Explosion:
    # Function or method implementation.
    def __init__(self, pos, radius, damage, ttl):
        self.pos = Vector2(pos)
        self.radius = radius
        self.damage = damage
        self.ttl = ttl
        self.max_ttl = ttl
        self.hit_done = False

    # Function or method implementation.
    def update(self, dt, game):
        self.ttl -= dt
        if not self.hit_done:
            self.hit_done = True
            if game.player.pos.distance_to(self.pos) < self.radius + game.player.radius:
                game.player.hit(self.damage, game)
                self.attack_anim = 0.22
            for enemy in game.enemies:
                if enemy.alive and enemy.pos.distance_to(self.pos) < self.radius + enemy.radius:
                    enemy.take_hit(max(8, self.damage // 2), game)
        return self.ttl > 0


# Base class for temporary battlefield events.
class Event:
    # Function or method implementation.
    def __init__(self, name, ttl):
        self.name = name
        self.ttl = ttl
        self.max_ttl = ttl

    # Function or method implementation.
    def update(self, dt, game):
        self.ttl -= dt
        return self.ttl > 0

    # Function or method implementation.
    def draw(self, surf, game):
        pass


# Hazards that sweep across lines and damage anything caught.
class CometLineEvent(Event):
    # Function or method implementation.
    def __init__(self):
        super().__init__('Comet Shear', 1.8)
        self.lines = []
        count = random.randint(1, 4)
        for _ in range(count):
            kind = random.choice(['h', 'v', 'd1', 'd2'])
            if kind == 'h':
                y = random.randint(80, WORLD_H - 80)
                self.lines.append(('h', y))
            elif kind == 'v':
                x = random.randint(80, WORLD_W - 80)
                self.lines.append(('v', x))
            elif kind == 'd1':
                c = random.randint(-WORLD_H//3, WORLD_W)
                self.lines.append(('d1', c))
            else:
                c = random.randint(0, WORLD_W + WORLD_H//3)
                self.lines.append(('d2', c))
        self.did_damage = False

    # Function or method implementation.
    def update(self, dt, game):
        alive = super().update(dt, game)
        if self.ttl < 0.9 and not self.did_damage:
            self.did_damage = True
            for line in self.lines:
                self._damage_line(line, game)
            game.audio.play('explode')
            game.camera.shake = max(game.camera.shake, 12)
        return alive

    # Function or method implementation.
    def _line_dist(self, line, pos):
        kind, v = line
        if kind == 'h':
            return abs(pos.y - v)
        if kind == 'v':
            return abs(pos.x - v)
        if kind == 'd1':
            return abs((pos.x - pos.y) - v) / 1.414
        return abs((pos.x + pos.y) - v) / 1.414

    # Function or method implementation.
    def _damage_line(self, line, game):
        width = 48
        if self._line_dist(line, game.player.pos) < width:
            game.player.hit(24, game)
        for enemy in game.enemies:
            if enemy.alive and self._line_dist(line, enemy.pos) < width:
                enemy.take_hit(999, game)
        for node in game.nodes:
            if node.alive and self._line_dist(line, node.pos) < width:
                ore = node.hit(999)
                if ore:
                    game.spawn_pickups(node.pos, ore)

    # Function or method implementation.
    def draw(self, surf, game):
        alpha = 90 if self.ttl > 0.9 else 180
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        comet_frames = getattr(game, 'object_strips', {}).get('comets', [])
        for line in self.lines:
            kind, v = line
            col = (255, 185, 90, alpha)
            if kind == 'h':
                y = int(game.camera.world_to_screen(Vector2(0, v)).y)
                pygame.draw.rect(overlay, col, (0, y - 12, WIDTH, 24))
                for sx in range(-40, WIDTH + 40, 120):
                    if comet_frames:
                        img = comet_frames[(sx // 120) % len(comet_frames)].copy()
                        img.set_alpha(alpha)
                        overlay.blit(img, img.get_rect(center=(sx, y)))
            elif kind == 'v':
                x = int(game.camera.world_to_screen(Vector2(v, 0)).x)
                pygame.draw.rect(overlay, col, (x - 12, 0, 24, HEIGHT))
                for sy in range(-40, HEIGHT + 40, 120):
                    if comet_frames:
                        img = pygame.transform.rotate(comet_frames[(sy // 120) % len(comet_frames)], -90)
                        img.set_alpha(alpha)
                        overlay.blit(img, img.get_rect(center=(x, sy)))
            elif kind == 'd1':
                p1 = game.camera.world_to_screen(Vector2(max(0, v), max(0, -v)))
                p2 = game.camera.world_to_screen(Vector2(min(WORLD_W, WORLD_H + v), min(WORLD_H, WORLD_W - v)))
                pygame.draw.line(overlay, col, p1, p2, 24)
                if comet_frames:
                    for t in [i / 6 for i in range(7)]:
                        pos = p1.lerp(p2, t)
                        img = pygame.transform.rotate(comet_frames[int(t * 10) % len(comet_frames)], -35)
                        img.set_alpha(alpha)
                        overlay.blit(img, img.get_rect(center=(int(pos.x), int(pos.y))))
            else:
                p1 = game.camera.world_to_screen(Vector2(max(0, v - WORLD_H), min(WORLD_H, v)))
                p2 = game.camera.world_to_screen(Vector2(min(WORLD_W, v), max(0, v - WORLD_W)))
                pygame.draw.line(overlay, col, p1, p2, 24)
                if comet_frames:
                    for t in [i / 6 for i in range(7)]:
                        pos = p1.lerp(p2, t)
                        img = pygame.transform.rotate(comet_frames[int(t * 10) % len(comet_frames)], 35)
                        img.set_alpha(alpha)
                        overlay.blit(img, img.get_rect(center=(int(pos.x), int(pos.y))))
        surf.blit(overlay, (0, 0))


# Event that spawns enemies near the player after a short delay.
class WarpAmbushEvent(Event):
    # Function or method implementation.
    def __init__(self):
        super().__init__('Warp Ambush', 2.4)
        self.spawned = False

    # Function or method implementation.
    def update(self, dt, game):
        alive = super().update(dt, game)
        if not self.spawned and self.ttl < 1.7:
            self.spawned = True
            for _ in range(random.randint(3, 5)):
                ang = random.random() * math.tau
                pos = game.player.pos + Vector2(math.cos(ang), math.sin(ang)) * random.randint(180, 280)
                pos.x = clamp(pos.x, 40, WORLD_W - 40)
                pos.y = clamp(pos.y, 40, WORLD_H - 40)
                game.enemies.append(Enemy(pos, random.choice(['spider', 'ufo', 'shooter']), game.wave))
            game.audio.play('rotate')
        return alive


# Event that adds light chip damage and visual pressure.
class SandSurgeEvent(Event):
    # Function or method implementation.
    def __init__(self):
        super().__init__('Sand Surge', 4.8)
        self.tick = 0.16

    # Function or method implementation.
    def update(self, dt, game):
        alive = super().update(dt, game)
        self.tick -= dt
        if self.tick <= 0:
            self.tick = 0.16
            center = game.player.pos + Vector2(random.uniform(-140, 140), random.uniform(-140, 140))
            for _ in range(8):
                vel = Vector2(random.uniform(-90, 90), random.uniform(-70, 70))
                game.particles.append(Particle(center, vel, YELLOW, random.randint(2, 4), 0.8))
            if random.random() < 0.45:
                game.player.hit(2, game, silent=True)
        return alive

    # Function or method implementation.
    def draw(self, surf, game):
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((200, 170, 90, 28))
        surf.blit(veil, (0, 0))


# Simple relic data container.
class VineSnareEvent(Event):
    """Forest biome hazard that grows grasping vines around the player."""
    def __init__(self):
        super().__init__('Vine Snare', 4.5)
        self.tick = 0.35

    def update(self, dt, game):
        alive = super().update(dt, game)
        self.tick -= dt
        if self.tick <= 0:
            self.tick = 0.35
            center = game.player.pos + Vector2(random.uniform(-90, 90), random.uniform(-90, 90))
            for _ in range(10):
                vel = Vector2(random.uniform(-80, 80), random.uniform(-80, 80))
                game.particles.append(Particle(center, vel, GREEN, random.randint(2, 4), 0.7))
            if random.random() < 0.4:
                game.player.hit(3, game, silent=True)
        return alive

    def draw(self, surf, game):
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((80, 170, 90, 24))
        surf.blit(veil, (0, 0))


class FrostNovaEvent(Event):
    """Frozen biome hazard that pulses icy damage and slow visuals."""
    def __init__(self):
        super().__init__('Frost Nova', 3.2)
        self.triggered = False

    def update(self, dt, game):
        alive = super().update(dt, game)
        if self.ttl < 1.6 and not self.triggered:
            self.triggered = True
            if game.player.pos.distance_to(game.player.pos) < 999999:
                game.player.hit(16, game)
            for enemy in game.enemies:
                if enemy.alive and enemy.pos.distance_to(game.player.pos) < 240:
                    enemy.take_hit(14, game)
            for _ in range(26):
                ang = random.random() * math.tau
                vel = Vector2(math.cos(ang), math.sin(ang)) * random.uniform(80, 180)
                game.particles.append(Particle(game.player.pos, vel, (180, 235, 255), 4, 0.9))
        return alive

    def draw(self, surf, game):
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((180, 220, 255, 20))
        surf.blit(veil, (0, 0))


class Relic:
    # Function or method implementation.
    def __init__(self, name, kind, charges):
        self.name = name
        self.kind = kind
        self.charges = charges


# The controllable hero and all run-based progression stats.
class Player:
    # Function or method implementation.
    def __init__(self, profile_data):
        self.pos = Vector2(WORLD_W/2, WORLD_H/2)
        self.vel = Vector2()
        self.radius = 18
        self.max_hp = 120
        self.hp = 120
        self.speed = 230
        self.damage = 12
        self.fire_delay = 0.22
        self.fire_cd = 0.0
        self.bullet_speed = 530
        self.projectiles = 1
        self.spread = 0.12
        self.pierce = 0
        self.magnet = 110
        self.combo = 0
        self.combo_timer = 0.0
        self.ore = 0
        self.disk_count = 0
        self.disk_radius = 72
        self.disk_speed = 2.7
        self.disk_damage = 11
        self.disks: List[OrbitalDisk] = []
        self.dash_cd = 0.0
        self.invuln = 0.0
        self.has_blink = profile_data.get('unlocks', {}).get('blink', False)
        self.has_shockwave = profile_data.get('unlocks', {}).get('shockwave', False)
        relic_data = profile_data.get('stored_relics', {'heal': 0, 'nova': 0, 'burst': 0})
        if isinstance(relic_data, int):
            relic_data = {'heal': relic_data, 'nova': 0, 'burst': 0}
        self.relics = {'heal': int(relic_data.get('heal', 0)), 'nova': int(relic_data.get('nova', 0)), 'burst': int(relic_data.get('burst', 0))}
        self.selected_relic = 'heal'
        self.skin = profile_data.get('skin', {'ship_tint': [255,255,255], 'trail_tint': [76,228,255]})
        self.anim_time = 0.0
        self.facing_right = True
        self.is_shooting = False
        self.temp_buffs: List[TemporaryBuff] = []
        self.shield = 0
        self.has_jet = profile_data.get('unlocks', {}).get('jetpack', False)
        self.alt_weapon = profile_data.get('unlocks', {}).get('alt_weapon', 'none')
        self.weapon_levels = profile_data.get('unlocks', {}).get('weapon_levels', {'shotgun': 0, 'laser': 0, 'rocket': 0})
        self.regen_rate = float(profile_data.get('unlocks', {}).get('regen_rate', 0.0))
        self.bombs = int(profile_data.get('unlocks', {}).get('bombs', 0))
        self.laser_heat = 0.0

    # Function or method implementation.
    def ensure_disks(self):
        if len(self.disks) != self.disk_count:
            self.disks = [OrbitalDisk(self, i, self.disk_count) for i in range(self.disk_count)]

    # Function or method implementation.
    def heal(self, amount):
        self.hp = min(self.max_hp, self.hp + amount)

    # Function or method implementation.
    def hit(self, damage, game, silent=False):
        if self.invuln > 0:
            return
        if self.shield > 0:
            self.shield -= 1
            self.invuln = 0.16
            game.camera.shake = max(game.camera.shake, 5)
            for _ in range(6):
                game.particles.append(Particle(self.pos.copy(), Vector2(random.uniform(-90, 90), random.uniform(-90, 90)), CYAN, 3, 0.24))
            if not silent:
                game.float_texts.append(FloatText('Shield', self.pos.copy(), CYAN))
            return
        self.hp -= damage
        self.invuln = 0.18
        game.camera.shake = max(game.camera.shake, 9)
        game.damage_flash = max(game.damage_flash, 0.16)
        for _ in range(9):
            game.particles.append(Particle(self.pos.copy(), Vector2(random.uniform(-120, 120), random.uniform(-120, 120)), RED, 4, 0.32))
        if not silent:
            game.float_texts.append(FloatText(f'-{damage}', self.pos.copy(), RED))
            game.audio.play('wall')

    def total_relics(self):
        return sum(self.relics.values())

    def grant_relic(self, kind=None):
        choices = ['heal', 'nova', 'burst']
        pick = kind if kind in choices else random.choice(choices)
        self.relics[pick] = self.relics.get(pick, 0) + 1
        if self.relics.get(self.selected_relic, 0) <= 0:
            self.selected_relic = pick

    def select_relic(self, kind):
        if kind in self.relics:
            self.selected_relic = kind

    # Returns the configured special weapon for right-click firing.
    def current_alt_weapon(self):
        return self.alt_weapon if self.alt_weapon in ('shotgun', 'laser', 'rocket') else 'none'

    def apply_effect(self, key):
        if key == 'damage':
            self.damage += 5
        elif key == 'scatter':
            self.projectiles = min(5, self.projectiles + 1)
            self.spread += 0.05
        elif key == 'firerate':
            self.fire_delay = max(0.08, self.fire_delay * 0.90)
        elif key == 'hull':
            self.max_hp += 20
            self.heal(20)
        elif key == 'speed':
            self.speed += 30
        elif key == 'disk':
            self.disk_count = min(5, self.disk_count + 1)
            self.ensure_disks()
        elif key == 'disk_torque':
            self.disk_speed += 0.55
            self.disk_damage += 5
        elif key == 'blink':
            self.has_blink = True
        elif key == 'shock':
            self.has_shockwave = True
        elif key == 'relic':
            self.grant_relic()
        elif key == 'jet':
            self.has_jet = True
        elif key == 'weapon_shotgun':
            self.alt_weapon = 'shotgun'
            self.weapon_levels['shotgun'] = self.weapon_levels.get('shotgun', 0) + 1
        elif key == 'weapon_laser':
            self.alt_weapon = 'laser'
            self.weapon_levels['laser'] = self.weapon_levels.get('laser', 0) + 1
        elif key == 'weapon_rocket':
            self.alt_weapon = 'rocket'
            self.weapon_levels['rocket'] = self.weapon_levels.get('rocket', 0) + 1
        elif key == 'regen':
            self.regen_rate += 0.45
        elif key == 'bomb':
            self.bombs += 2
        elif key == 'shield':
            self.shield += 2
        elif key == 'buff_rapid':
            self.temp_buffs.append(TemporaryBuff('rapid', 18.0))
        elif key == 'buff_rage':
            self.temp_buffs.append(TemporaryBuff('rage', 18.0))
        elif key == 'heal':
            self.heal(30)
        elif key == 'ore':
            self.ore += 35

    # Function or method implementation.
    def use_relic(self, game):
        kind = self.selected_relic
        if self.relics.get(kind, 0) <= 0:
            for alt in ('heal', 'nova', 'burst'):
                if self.relics.get(alt, 0) > 0:
                    kind = alt
                    self.selected_relic = alt
                    break
            else:
                return
        self.relics[kind] -= 1
        if kind == 'heal':
            self.heal(60)
            self.shield += 1
            game.heal_flash = max(game.heal_flash, 0.12)
            for _ in range(10):
                game.particles.append(Particle(self.pos.copy(), Vector2(random.uniform(-70,70), random.uniform(-70,70)), GREEN, 4, 0.45))
            game.float_texts.append(FloatText('Restoration Relic', self.pos.copy(), GREEN))
        elif kind == 'nova':
            for enemy in game.enemies:
                enemy.take_hit(26 + game.wave // 2, game)
            for _ in range(3):
                game.explosions.append(Explosion(self.pos + Vector2(random.uniform(-50,50), random.uniform(-50,50)), 110, 18 + game.wave // 2, 0.25))
            game.float_texts.append(FloatText('Nova Relic', self.pos.copy(), CYAN))
        else:
            for i in range(24):
                ang = i / 24 * math.tau
                vel = Vector2(math.cos(ang), math.sin(ang)) * (self.bullet_speed + 90)
                game.player_bullets.append(Bullet(self.pos, vel, self.damage + 8, 'player', 5, PURPLE, self.pierce + 1))
            self.temp_buffs.append(TemporaryBuff('rapid', 6.0))
            game.float_texts.append(FloatText('Burst Relic', self.pos.copy(), PURPLE))
        game.audio.play('clear')

    # Function or method implementation.
    def update(self, dt, game, keys):
        rate_bonus = 1.0
        speed_bonus = 1.0
        damage_bonus = 0
        magnet_bonus = 0
        kept_buffs: List[TemporaryBuff] = []
        for buff in self.temp_buffs:
            buff.ttl -= dt
            if buff.ttl > 0:
                kept_buffs.append(buff)
                if buff.kind == 'rapid':
                    rate_bonus += 0.55
                elif buff.kind == 'rage':
                    damage_bonus += 5
                elif buff.kind == 'haste':
                    speed_bonus += 0.28
                elif buff.kind == 'magnet':
                    magnet_bonus += 80
        self.temp_buffs = kept_buffs
        self.magnet = 110 + magnet_bonus
        if self.regen_rate > 0 and self.hp < self.max_hp:
            self.hp = min(self.max_hp, self.hp + self.regen_rate * dt)

        move = Vector2(
            (keys[pygame.K_d] or keys[pygame.K_RIGHT]) - (keys[pygame.K_a] or keys[pygame.K_LEFT]),
            (keys[pygame.K_s] or keys[pygame.K_DOWN]) - (keys[pygame.K_w] or keys[pygame.K_UP]),
        )
        if move.length_squared() > 0:
            move = move.normalize()
        self.vel = move * (self.speed * speed_bonus)
        self.pos += self.vel * dt
        self.pos.x = clamp(self.pos.x, 24, WORLD_W - 24)
        self.pos.y = clamp(self.pos.y, 24, WORLD_H - 24)
        self.fire_cd -= dt
        self.dash_cd -= dt
        self.invuln -= dt
        self.combo_timer -= dt
        if self.combo_timer <= 0:
            self.combo = 0

        mouse_world = game.camera.screen_to_world(pygame.mouse.get_pos())
        aim = mouse_world - self.pos
        if aim.length_squared() == 0:
            aim = Vector2(1, 0)
        aim = aim.normalize()

        self.anim_time += dt
        self.is_shooting = pygame.mouse.get_pressed()[0]
        if aim.x != 0:
            self.facing_right = aim.x >= 0

        if pygame.mouse.get_pressed()[0] and self.fire_cd <= 0 and game.state == 'playing':
            rate_bonus = max(0.15, rate_bonus)
            self.fire_cd = self.fire_delay / rate_bonus
            count = self.projectiles
            for i in range(count):
                ang = 0 if count == 1 else (i - (count - 1)/2) * math.degrees(self.spread)
                vec = aim.rotate(ang)
                b = Bullet(self.pos + vec * 22, vec * self.bullet_speed, self.damage + damage_bonus, 'player', 5, CYAN, self.pierce)
                b.sprite_key = 'pulse'
                game.player_bullets.append(b)
                game.particles.append(Particle(self.pos + vec * 18, vec * 70 + Vector2(random.uniform(-18, 18), random.uniform(-18, 18)), CYAN, 3, 0.16))
            game.camera.shake = max(game.camera.shake, 2.5)
            game.audio.play('weapon_laser')

        if pygame.mouse.get_pressed()[2] and self.fire_cd <= 0 and game.state == 'playing' and self.current_alt_weapon() != 'none':
            rate_bonus = max(0.15, rate_bonus)
            alt = self.current_alt_weapon()
            if alt == 'shotgun':
                lvl = max(1, self.weapon_levels.get('shotgun', 1))
                self.fire_cd = max(0.34, 0.7 - lvl * 0.03) / rate_bonus
                pellets = 6 + lvl
                self.pos -= aim * min(28, 6 + lvl * 2)
                for _ in range(pellets):
                    ang = random.uniform(-(16 + lvl * 2), 16 + lvl * 2)
                    vec = aim.rotate(ang)
                    dmg = self.damage + damage_bonus + 2 + lvl
                    b = Bullet(self.pos + vec * 18, vec * (390 + lvl * 22), dmg, 'player', 4, YELLOW, 0)
                    b.sprite_key = 'shotgun'
                    game.player_bullets.append(b)
                    game.particles.append(Particle(self.pos + vec * 18, vec * 60 + Vector2(random.uniform(-22, 22), random.uniform(-22, 22)), ORANGE, 3, 0.15))
                    game.audio.play('weapon_pellet')
            elif alt == 'laser':
                lvl = max(1, self.weapon_levels.get('laser', 1))
                self.fire_cd = max(0.22, 0.72 - lvl * 0.05) / rate_bonus
                game.camera.shake = max(game.camera.shake, 4)
                game.fire_laser(self.pos + aim * 24, aim, self.damage + damage_bonus + 9 + lvl * 4, 10 + lvl * 2)
            elif alt == 'rocket':
                lvl = max(1, self.weapon_levels.get('rocket', 1))
                self.fire_cd = max(0.38, 0.92 - lvl * 0.04) / rate_bonus
                rocket = Bullet(self.pos + aim * 18, aim * (400 + lvl * 16), self.damage + damage_bonus + 12 + lvl * 5, 'player', 8, ORANGE, 0)
                rocket.explosive = True
                rocket.explosion_radius = 92 + lvl * 12
                rocket.sprite_key = 'rocket'
                game.player_bullets.append(rocket)
            if alt == 'shotgun':
                game.audio.play('weapon_shotgun')
            elif alt == 'laser':
                game.audio.play('weapon_laser')
            elif alt == 'rocket':
                game.audio.play('weapon_rocket')

        if keys[pygame.K_SPACE] and self.dash_cd <= 0 and move.length_squared() > 0:
            self.pos += move * 110
            self.dash_cd = 1.0
            self.invuln = 0.18
            for _ in range(8):
                game.particles.append(Particle(self.pos, Vector2(random.uniform(-120,120), random.uniform(-120,120)), CYAN, 3, 0.35))
            if self.has_shockwave:
                game.explosions.append(Explosion(self.pos, 78, 12, 0.25))


        if keys[pygame.K_LSHIFT] and self.has_jet and self.dash_cd <= 0:
            self.pos += aim * 100
            self.pos.x = clamp(self.pos.x, 24, WORLD_W - 24)
            self.pos.y = clamp(self.pos.y, 24, WORLD_H - 24)
            self.dash_cd = 0.75
            self.invuln = 0.15
            for _ in range(12):
                game.particles.append(Particle(self.pos, Vector2(random.uniform(-110,110), random.uniform(-110,110)), ORANGE, 4, 0.35))

        if keys[pygame.K_q] and self.has_blink and self.dash_cd <= 0:
            self.pos += aim * 160
            self.pos.x = clamp(self.pos.x, 24, WORLD_W - 24)
            self.pos.y = clamp(self.pos.y, 24, WORLD_H - 24)
            self.dash_cd = 1.2
            self.invuln = 0.18
            for _ in range(10):
                game.particles.append(Particle(self.pos, Vector2(random.uniform(-140,140), random.uniform(-140,140)), PURPLE, 4, 0.4))
            game.audio.play('rotate')

        self.ensure_disks()
        for disk in self.disks:
            disk.update(dt, game)


# Main game application: state management, rendering, input, and persistence.
class Game:
    # Function or method implementation.
    def __init__(self):
        pygame.init()
        self.settings = self.load_settings()
        globals()['WIDTH'], globals()['HEIGHT'] = self.settings.get('window_size', [1280, 720])
        pygame.display.set_caption(TITLE)
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        self.clock = pygame.time.Clock()
        self.ui_scale = float(self.settings.get('ui_scale', 1.0))
        self.text_size = int(self.settings.get('text_size', 100))
        self.sfx_volume = float(self.settings.get('sfx_volume', 0.75))
        self.music_volume = float(self.settings.get('music_volume', 0.35))
        self.window_sizes = [(960, 540), (1280, 720), (1600, 900), (1920, 1080)]
        self.apply_ui_settings()
        self.audio = Audio(self.sfx_volume, self.music_volume)
        self.camera = Camera()
        self.damage_flash = 0.0
        self.heal_flash = 0.0
        self.combo_glow = 0.0
        try:
            self.bg_sheet = load_raw_image('environment space sprite.png')
        except FileNotFoundError:
            self.bg_sheet = pygame.Surface((1600, 900), pygame.SRCALPHA)
            self.bg_sheet.fill((0, 0, 0, 0))
        self.bg_panorama_sheet = load_raw_image('space forest and moon.png') if (ASSET_DIR / 'space forest and moon.png').exists() else self.bg_sheet
        self.bg_bands = slice_background_bands(self.bg_panorama_sheet)
        self.env_backdrop = pygame.transform.smoothscale(self.bg_bands[0] if self.bg_bands else self.bg_panorama_sheet, (WIDTH, HEIGHT))
        player_boxes = {
            'idle': [(250, 60, 430, 320), (480, 60, 670, 320), (705, 60, 895, 320), (940, 60, 1125, 320)],
            'run': [(245, 355, 455, 625), (500, 355, 690, 625), (735, 355, 945, 625), (965, 355, 1165, 625)],
            'jump': [(255, 650, 475, 920), (505, 650, 760, 920), (760, 650, 1015, 920)],
            'shoot': [(240, 945, 585, 1210), (565, 945, 800, 1210), (845, 945, 1035, 1210)],
            'hurt': [(235, 1230, 470, 1445), (485, 1230, 750, 1445)],
            'dead': [(210, 1480, 450, 1625), (470, 1480, 760, 1625), (800, 1480, 1125, 1625)],
            'jetpack': [(90, 1640, 280, 1895), (300, 1640, 495, 1895), (520, 1640, 715, 1895), (740, 1640, 930, 1895), (950, 1640, 1135, 1895)],
        }
        self.player_frames = slice_frames('spaceman sprite.png', player_boxes, 88)
        self.enemy_frames = load_enemy_animation_set()
        self.enemy_anim_speed = {'crawler': 7, 'brute': 7, 'shooter': 8, 'spider': 10, 'tank': 6, 'ufo': 7, 'soldier': 9, 'grunt': 8, 'rifleman': 9, 'bomber': 11, 'warper': 8, 'grenadier': 6, 'elite': 7}
        self.assets = {
            'alien1': load_image('alien_1.png', 42),
            'alien2': load_image('alien_2.png', 42),
            'alien3': load_image('alien_3.png', 42),
            'food': load_image('food.png', 24),
            'mystery': load_image('mystery.png', 24),
            'pot_heal': crop_safe(self.bg_sheet, (60, 820, 190, 995), 42, False),
            'pot_buff': crop_safe(self.bg_sheet, (205, 820, 335, 995), 42, False),
            'obstacle': crop_safe(self.bg_sheet, (770, 1195, 1145, 1410), 98, False),
            'obstacle_small': crop_safe(self.bg_sheet, (1190, 1270, 1360, 1465), 72, False),
            'obstacle_tower': crop_safe(self.bg_sheet, (1510, 20, 1655, 285), 130, False),
            'obstacle_console': crop_safe(self.bg_sheet, (820, 15, 1030, 160), 72, False),
            'obstacle_dish': crop_safe(self.bg_sheet, (1040, 470, 1270, 665), 92, False),
            'obstacle_crate': crop_safe(self.bg_sheet, (650, 470, 790, 610), 62, False),
            'station': crop_safe(self.bg_sheet, (360, 210, 1235, 690), 150, False),
            'ore_node': crop_safe(self.bg_sheet, (1130, 770, 1260, 930), 42, False),
            'pickup_heal': crop_safe(self.bg_sheet, (150, 1510, 275, 1665), 36, False),
            'pickup_buff': crop_safe(self.bg_sheet, (20, 1550, 120, 1665), 34, False),
            'deco_frame': crop_safe(self.bg_sheet, (30, 1000, 360, 1235), 78, False),
            'deco_platform': crop_safe(self.bg_sheet, (470, 1310, 1120, 1500), 64, False),
            'deco_terminal': crop_safe(self.bg_sheet, (300, 720, 490, 980), 82, False),
            'deco_lab': crop_safe(self.bg_sheet, (820, 450, 1510, 830), 120, False),
        }
        self.object_strips = {
            'items': slice_object_strip('items.png', 7, 42),
            'comets': slice_object_strip('comet.png', 6, 54),
            'ore_clusters': slice_object_strip('ores and rocks 1.png', 5, 46),
            'asteroids': slice_object_strip('asteroids.png', 5, 52),
            'minerals': slice_object_strip('minerals.png', 5, 48),
        }
        self.assets['obstacle'] = self.object_strips['asteroids'][0]
        self.assets['obstacle_small'] = self.object_strips['asteroids'][1 if len(self.object_strips['asteroids']) > 1 else 0]
        self.assets['obstacle_crate'] = self.object_strips['ore_clusters'][0]
        self.assets['obstacle_console'] = self.object_strips['items'][2]
        self.assets['ore_node'] = self.object_strips['minerals'][0]
        self.assets['deco_platform'] = load_clean_image('space module 1.png', 78, True)
        self.assets['station'] = load_clean_image('space module 2.png', 126, True)
        self.assets['deco_lab'] = load_clean_image('space module 2.png', 126, True)
        self.assets['deco_frame'] = load_clean_image('space module 3.png', 74, True)
        self.assets['obstacle_tower'] = load_clean_image('space env obj1.png', 92, True)
        self.assets['obstacle_console'] = load_clean_image('space env obj2.png', 56, True)
        self.assets['obstacle_dish'] = load_clean_image('space env obj3.png', 62, True)
        self.assets['pot_heal'] = load_clean_image('potion.png', 34, True)
        self.assets['pot_buff'] = load_clean_image('item1.png', 34, True)
        self.weapon_icons = {
            'laser': load_weapon_icon('laser gun.png', 34),
            'rocket': load_weapon_icon('rocket launcher.png', 34),
            'shotgun': load_weapon_icon('shotgun.png', 34),
            'pulse': load_weapon_icon('pulse shots.png', 34),
            'rapid': load_weapon_icon('rapid shots.png', 30),
            'missile': load_weapon_icon('missile.png', 30),
            'beam': load_weapon_icon('beam gun.png', 30),
            'plasma': load_weapon_icon('plasmagun.png', 30),
        }
        self.projectile_sprites = {
            'pulse': slice_object_strip('pulse shots.png', 6, 18),
            'laser': slice_object_strip('laser gun.png', 3, 18),
            'rocket': slice_object_strip('rocket launcher.png', 3, 18),
            'missile': slice_object_strip('missile.png', 3, 18),
            'shotgun': slice_object_strip('shotgun.png', 4, 18),
            'plasma': slice_object_strip('plasmagun.png', 5, 18),
            'rapid': slice_object_strip('rapid shots.png', 6, 18),
            'beam': slice_object_strip('beam gun.png', 4, 18),
        }
        self.menu_ui = {
            'frame': load_ui_sprite('menu.png'),
            'btn_blue': load_ui_sprite('ready.png'),
            'btn_shop': load_ui_sprite('shop.png'),
            'btn_inventory': load_ui_sprite('inventory.png'),
            'dropdown': load_ui_sprite('menu.png'),
        }
        self.ui_art = {
            'title': load_ui_sprite('title.png'),
            'panel': load_ui_sprite('menu.png'),
            'bars': load_ui_sprite('hp shield bar.png'),
            'level': load_ui_sprite('level.png'),
            'score1': load_ui_sprite('score1.png'),
            'score2': load_ui_sprite('score2.png'),
            'damage': load_ui_sprite('damage.png'),
            'equip': load_ui_sprite('equip.png'),
            'ready': load_ui_sprite('ready.png'),
            'shop': load_ui_sprite('shop.png'),
            'inventory': load_ui_sprite('inventory.png'),
            'ui_icons': load_ui_sprite('ui icons.png'),
            'ui_icons2': load_ui_sprite('user interface icon.png'),
            'item1': load_ui_sprite('item1.png'),
            'potion': load_ui_sprite('potion.png'),
            'mineral': load_ui_sprite('mineral icon.png'),
            'golds': load_ui_sprite('items and golds.png'),
        }
        self.stage_music = ['deep_space_ost.wav', 'toxic_green_space_relaxing.wav', 'glacier_deep_space_ost.wav', 'deep_space_ost.wav']
        self.current_music_stage = -1
        self.generated_ui_bg = load_ui_sprite('space forest and moon.png') if (ASSET_DIR / 'space forest and moon.png').exists() else None
        self.ui_generated = {
            'panel': load_ui_sprite('ui_frame_main.png'),
            'header': load_ui_sprite('title1.png'),
            'header_alt': load_ui_sprite('title2.png'),
            'button': load_ui_sprite('button1.png'),
            'button_small': load_ui_sprite('menu button2.png'),
            'button_green': load_ui_sprite('button1.png'),
        }
        self.ui_parts = {
            'left': load_ui_sprite('left.png') if (ASSET_DIR / 'left.png').exists() else None,
            'center': load_ui_sprite('center.png') if (ASSET_DIR / 'center.png').exists() else None,
            'right': load_ui_sprite('right.png') if (ASSET_DIR / 'right.png').exists() else None,
            'icon1': load_ui_sprite('icon1.png') if (ASSET_DIR / 'icon1.png').exists() else None,
            'icon2': load_ui_sprite('icon2.png') if (ASSET_DIR / 'icon2.png').exists() else None,
            'corner': load_ui_sprite('corner.png') if (ASSET_DIR / 'corner.png').exists() else None,
            'corner2': load_ui_sprite('corner2.png') if (ASSET_DIR / 'corner2.png').exists() else None,
            'corner3': load_ui_sprite('corner3.png') if (ASSET_DIR / 'corner3.png').exists() else None,
            'slot1': load_ui_sprite('slot1.png') if (ASSET_DIR / 'slot1.png').exists() else None,
            'slot2': load_ui_sprite('slot2.png') if (ASSET_DIR / 'slot2.png').exists() else None,
            'slot3': load_ui_sprite('slot3.png') if (ASSET_DIR / 'slot3.png').exists() else None,
            'hpbar': load_ui_sprite('hpbar.png') if (ASSET_DIR / 'hpbar.png').exists() else None,
            'shieldbar': load_ui_sprite('shieldbar.png') if (ASSET_DIR / 'shieldbar.png').exists() else None,
            'map': load_ui_sprite('map.png') if (ASSET_DIR / 'map.png').exists() else None,
        }
        self.profile_index = 0
        self.profile_index = 0
        self.mode_index = 0
        self.menu_index = 0
        self.menu_items = ['Start Run', 'Load Saved Run', 'Mode', 'Settings', 'Controls', 'Customize', 'Quit']
        self.tint_index = 0
        self.trail_index = 0
        self.colors = [WHITE, CYAN, YELLOW, GREEN, PURPLE, RED, ORANGE]
        self.menu_rects: Dict[str, pygame.Rect] = {}
        self.shop_free_rects: List[pygame.Rect] = []
        self.shop_item_rects: List[pygame.Rect] = []
        self.shop_next_rect = pygame.Rect(0, 0, 0, 0)
        self.shop_refresh_rect = pygame.Rect(0, 0, 0, 0)
        self.hovered_menu_item: Optional[str] = None
        self.menu_section = None
        self.submenu_rects: Dict[str, pygame.Rect] = {}
        self.decorations: List[Decoration] = []
        self.wave_spawn_remaining = 0
        self.batch_spawn_timer = 0.0
        self.wave_purchase_count = 0
        self.free_pick_count = 0
        self.max_free_picks = 1
        self.max_shop_purchases = 2
        self.shop_refreshes = 1
        self.boss_wave = False
        self.stage_clear_delay = 0.0
        self.profiles = self.load_profiles()
        self.state = 'menu'
        self.pause_index = 0
        self.event_timer = 6.0
        self.reset_run(new_run=True)
        self.refresh_stage_music(True)

    # Function or method implementation.
    def load_settings(self):
        if SETTINGS_FILE.exists():
            try:
                return json.loads(SETTINGS_FILE.read_text())
            except Exception:
                pass
        data = {'ui_scale': 1.0, 'text_size': 100, 'window_size': [1280, 720], 'sfx_volume': 0.75, 'music_volume': 0.35}
        SETTINGS_FILE.write_text(json.dumps(data, indent=2))
        return data

    # Function or method implementation.
    def save_settings(self):
        self.settings['ui_scale'] = self.ui_scale
        self.settings['text_size'] = self.text_size
        self.settings['window_size'] = [WIDTH, HEIGHT]
        self.settings['sfx_volume'] = self.sfx_volume
        self.settings['music_volume'] = self.music_volume
        SETTINGS_FILE.write_text(json.dumps(self.settings, indent=2))

    # Function or method implementation.
    def apply_ui_settings(self):
        sm = max(14, int(18 * self.ui_scale * (self.text_size / 100)))
        md = max(20, int(26 * self.ui_scale * (self.text_size / 100)))
        lg = max(34, int(48 * self.ui_scale * (self.text_size / 100)))
        xl = max(48, int(64 * self.ui_scale * (self.text_size / 100)))
        self.font_sm = pygame.font.SysFont('consolas', sm)
        self.font_md = pygame.font.SysFont('consolas', md, bold=True)
        self.font_lg = pygame.font.SysFont('consolas', lg, bold=True)
        self.font_xl = pygame.font.SysFont('consolas', xl, bold=True)

    def apply_window_size(self, size: Tuple[int, int]):
        globals()['WIDTH'], globals()['HEIGHT'] = size
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        self.save_settings()

    def apply_audio_settings(self):
        self.audio.set_sfx_volume(self.sfx_volume)
        self.audio.set_music_volume(self.music_volume)
        self.save_settings()

    # Function or method implementation.
    def default_profiles(self):
        return {
            'profiles': [
                {'name': 'Pilot 1', 'highscores': {m: 0 for m in MODE_LIST}, 'stored_relics': {'heal': 0, 'nova': 0, 'burst': 0}, 'stored_buffs': [], 'unlocks': {'blink': False, 'shockwave': False, 'jetpack': False, 'alt_weapon': 'none', 'weapon_levels': {'shotgun': 0, 'laser': 0, 'rocket': 0}, 'regen_rate': 0.0, 'bombs': 0}, 'skin': {'ship_tint': [255,255,255], 'trail_tint': [76,228,255]}},
                {'name': 'Pilot 2', 'highscores': {m: 0 for m in MODE_LIST}, 'stored_relics': {'heal': 0, 'nova': 0, 'burst': 0}, 'stored_buffs': [], 'unlocks': {'blink': False, 'shockwave': False, 'jetpack': False, 'alt_weapon': 'none', 'weapon_levels': {'shotgun': 0, 'laser': 0, 'rocket': 0}, 'regen_rate': 0.0, 'bombs': 0}, 'skin': {'ship_tint': [255,255,255], 'trail_tint': [76,228,255]}},
                {'name': 'Pilot 3', 'highscores': {m: 0 for m in MODE_LIST}, 'stored_relics': {'heal': 0, 'nova': 0, 'burst': 0}, 'stored_buffs': [], 'unlocks': {'blink': False, 'shockwave': False, 'jetpack': False, 'alt_weapon': 'none', 'weapon_levels': {'shotgun': 0, 'laser': 0, 'rocket': 0}, 'regen_rate': 0.0, 'bombs': 0}, 'skin': {'ship_tint': [255,255,255], 'trail_tint': [76,228,255]}},
            ]
        }

    # Function or method implementation.
    def load_profiles(self):
        if PROFILE_FILE.exists():
            try:
                data = json.loads(PROFILE_FILE.read_text())
                if 'profiles' in data and len(data['profiles']) == 3:
                    return data
            except Exception:
                pass
        data = self.default_profiles()
        PROFILE_FILE.write_text(json.dumps(data, indent=2))
        return data

    # Function or method implementation.
    def save_profiles(self):
        PROFILE_FILE.write_text(json.dumps(self.profiles, indent=2))

    @property
    # Function or method implementation.
    def profile(self):
        return self.profiles['profiles'][self.profile_index]

    @property
    # Function or method implementation.
    def mode_name(self):
        return MODE_LIST[self.mode_index]

    # Function or method implementation.
    def reset_run(self, new_run=True):
        self.player = Player(self.profile)
        self.player_bullets: List[Bullet] = []
        self.enemy_bullets: List[Bullet] = []
        self.laser_beams: List[LaserBeam] = []
        self.enemies: List[Enemy] = []
        self.nodes: List[OreNode] = []
        self.obstacles: List[Obstacle] = []
        self.particles: List[Particle] = []
        self.explosions: List[Explosion] = []
        self.float_texts: List[FloatText] = []
        self.pickups: List[Pickup] = []
        self.loot_pots: List[LootPot] = []
        self.active_event: Optional[Event] = None
        self.decorations = []
        self.wave = 1
        self.score = 0
        self.shop_items = []
        self.free_choices = []
        self.event_timer = 6.0
        self.intermission_pick_done = False
        self.wave_purchase_count = 0
        self.stage_clear_delay = 0.0
        self.free_pick_count = 0
        self.damage_flash = 0.0
        self.heal_flash = 0.0
        self.combo_glow = 0.0
        self.shop_refreshes = 1
        self.batch_spawn_timer = 0.0
        self.wave_spawn_remaining = 0
        if new_run:
            self.spawn_wave()

    # Function or method implementation.
    def reroll_shop(self):
        mult = GAME_MODES[self.mode_name]['shop_mult']
        self.shop_items = []
        for name, base, desc, key in random.sample(SHOP_DEFS, 4):
            cost = int(base * mult + self.wave * 7 + self.wave_purchase_count * 12)
            self.shop_items.append({'name': name, 'cost': cost, 'desc': desc, 'key': key})
        self.free_choices = random.sample(FREEBIES, 3)
        self.intermission_pick_done = False
        self.free_pick_count = 0
        self.wave_purchase_count = 0
        self.shop_refreshes = 1

    # Function or method implementation.
    def spawn_pickups(self, pos, ore):
        count = max(1, ore // 8)
        for _ in range(count):
            jitter = Vector2(random.uniform(-18,18), random.uniform(-18,18))
            self.pickups.append(Pickup(Vector2(pos) + jitter, 'ore', max(1, ore // count)))
        if random.random() < 0.08:
            self.pickups.append(Pickup(Vector2(pos), 'relic', 1))

    # Function or method implementation.
    def build_wave_roster(self):
        stage = self.current_stage_index()
        if stage == 0:
            kinds = ['grunt', 'soldier', 'crawler', 'spider', 'bomber']
            weights = [4, 4, 4, 3, 2]
        elif stage == 1:
            kinds = ['spider', 'warper', 'shooter', 'crawler', 'grenadier']
            weights = [4, 3, 3, 3, 2]
        elif stage == 2:
            kinds = ['tank', 'rifleman', 'warper', 'bomber', 'elite']
            weights = [3, 4, 3, 2, 2]
        else:
            kinds = ['elite', 'grenadier', 'bomber', 'ufo', 'brute', 'warper']
            weights = [3, 3, 3, 3, 2, 3]
        if self.wave >= 8:
            kinds += ['rifleman', 'shooter']
            weights += [2, 2]
        if self.wave >= 12:
            kinds += ['tank']
            weights += [2]
        return kinds, weights

    # Function or method implementation.
    def add_environment_decor(self):
        self.decorations = []
        deco_keys = ['station', 'deco_terminal', 'deco_lab', 'deco_frame', 'deco_platform', 'obstacle_dish', 'obstacle_console', 'obstacle_tower', 'obstacle_crate']
        strip_keys = ['items', 'comets', 'ore_clusters', 'asteroids', 'minerals']
        for _ in range(10 + self.wave):
            key = random.choice(strip_keys) if random.random() < 0.45 else random.choice(deco_keys)
            pos = Vector2(random.randint(90, WORLD_W - 90), random.randint(90, WORLD_H - 90))
            if pos.distance_to(self.player.pos) > 260:
                self.decorations.append(Decoration(pos, key, random.uniform(0.85, 1.2), random.uniform(0, math.tau)))

    # Function or method implementation.
    def random_spawn_point(self, min_dist=360, max_dist=None):
        # Enemies appear around the map but never too close to the player's avatar.
        for _ in range(60):
            pos = Vector2(random.randint(60, WORLD_W - 60), random.randint(60, WORLD_H - 60))
            dist = pos.distance_to(self.player.pos)
            if dist > min_dist and (max_dist is None or dist < max_dist):
                return pos
        return Vector2(random.randint(60, WORLD_W - 60), random.randint(60, WORLD_H - 60))

    def boss_count_for_wave(self):
        return 1 + max(0, (self.wave - 1) // 40)

    def spawn_enemy_batch(self, count):
        kinds, weights = self.build_wave_roster()
        for _ in range(count):
            pos = self.random_spawn_point()
            kind = random.choices(kinds, weights=weights)[0]
            self.enemies.append(Enemy(pos, kind, self.wave))

    def spawn_bosses(self, count):
        stage = self.current_stage_index()
        for i in range(count):
            if stage == 0:
                boss = Boss(self.random_spawn_point(), 'brute', self.wave, i + 1)
                boss.sprite_kind = 'boss1'
                boss.name = 'Molten Colossus'
                boss.speed = max(60, int(boss.speed * 0.82))
                boss.reward += 40
            elif stage == 1:
                boss = Boss(self.random_spawn_point(), 'warper', self.wave, i + 1)
                boss.sprite_kind = 'boss2'
                boss.name = 'Void Saucer'
                boss.shoot_range = 520
                boss.reward += 50
            elif stage == 2:
                boss = Boss(self.random_spawn_point(), 'brute', self.wave, i + 1)
                boss.sprite_kind = 'boss3'
                boss.name = 'Frozen Juggernaut'
                boss.speed = max(58, int(boss.speed * 0.76))
                boss.reward += 60
            else:
                boss_kinds = ['tank', 'ufo', 'shooter', 'rifleman']
                boss = Boss(self.random_spawn_point(), boss_kinds[i % len(boss_kinds)], self.wave, i + 1)
            self.enemies.append(boss)

    # Function or method implementation.
    def spawn_wave(self):
        mode = GAME_MODES[self.mode_name]
        self.enemies.clear()
        self.nodes.clear()
        self.obstacles.clear()
        self.enemy_bullets.clear()
        self.loot_pots.clear()
        self.decorations.clear()
        self.wave_spawn_remaining = 0
        self.batch_spawn_timer = 3.0
        self.boss_wave = (self.wave % 5 == 0)
        enemy_total = int((6 + self.wave * 2.2) * mode['enemy_mult'])
        node_total = max(1, int((2 + self.wave // 2) * mode['node_mult']))
        obstacle_total = 12 + self.wave * 2
        obstacle_styles = ['obstacle_small', 'obstacle', 'obstacle_console', 'obstacle_crate', 'obstacle_dish', 'obstacle_tower']
        for _ in range(obstacle_total):
            pos = Vector2(random.randint(120, WORLD_W-120), random.randint(120, WORLD_H-120))
            if pos.distance_to(self.player.pos) > 280:
                obs = Obstacle(pos, random.randint(22, 44))
                obs.style = random.choice(obstacle_styles)
                self.obstacles.append(obs)
        self.add_environment_decor()
        for _ in range(max(2, 1 + self.wave // 2)):
            pos = Vector2(random.randint(120, WORLD_W-120), random.randint(120, WORLD_H-120))
            if pos.distance_to(self.player.pos) > 220:
                self.loot_pots.append(LootPot(pos, random.choice(['heal', 'buff'])))
        for _ in range(node_total):
            for _try in range(40):
                pos = Vector2(random.randint(120, WORLD_W-120), random.randint(120, WORLD_H-120))
                if all(pos.distance_to(obs.pos) > obs.radius + 48 for obs in self.obstacles):
                    self.nodes.append(OreNode(pos, 1 + self.wave // 3))
                    break
        if self.boss_wave:
            self.spawn_bosses(self.boss_count_for_wave())
            self.wave_spawn_remaining = max(0, enemy_total // 2)
        else:
            initial_batch = min(7 + self.wave // 2, enemy_total)
            self.spawn_enemy_batch(initial_batch)
            self.wave_spawn_remaining = max(0, enemy_total - initial_batch)

    def refresh_shop(self):
        # Reroll the shop stock without consuming purchase limits for the wave.
        if self.shop_refreshes <= 0:
            self.float_texts.append(FloatText('No refresh left', self.player.pos.copy(), ORANGE))
            return
        self.shop_refreshes -= 1
        mult = GAME_MODES[self.mode_name]['shop_mult']
        self.shop_items = []
        for name, base, desc, key in random.sample(SHOP_DEFS, 4):
            cost = int(base * mult + self.wave * 7 + self.wave_purchase_count * 12)
            self.shop_items.append({'name': name, 'cost': cost, 'desc': desc, 'key': key})
        self.audio.play('rotate')
        self.float_texts.append(FloatText('Shop refreshed', self.player.pos.copy(), CYAN))

    def fire_laser(self, start, direction, damage, width):
        end = Vector2(start) + Vector2(direction) * 1200
        self.laser_beams.append(LaserBeam(start, end, width, PURPLE))
        self.camera.shake = max(self.camera.shake, 4)
        for _ in range(10):
            self.particles.append(Particle(Vector2(start), Vector2(direction) * random.uniform(80, 160) + Vector2(random.uniform(-24,24), random.uniform(-24,24)), PURPLE, 3, 0.2))
        self.audio.play('weapon_laser')
        for enemy in self.enemies:
            if enemy.alive and point_line_distance(enemy.pos, Vector2(start), end) < enemy.radius + width:
                enemy.take_hit(damage, self)
        for node in self.nodes:
            if node.alive and point_line_distance(node.pos, Vector2(start), end) < node.radius + width:
                ore = node.hit(damage)
                if ore:
                    self.spawn_pickups(node.pos, ore)
        for pot in self.loot_pots:
            if pot.alive and point_line_distance(pot.pos, Vector2(start), end) < pot.radius + width:
                pot.hit(damage, self)

    def save_run(self):
        data = {
            'profile_index': self.profile_index,
            'mode_name': self.mode_name,
            'wave': self.wave,
            'score': self.score,
            'player': {
                'hp': self.player.hp, 'max_hp': self.player.max_hp, 'speed': self.player.speed,
                'damage': self.player.damage, 'fire_delay': self.player.fire_delay, 'projectiles': self.player.projectiles,
                'spread': self.player.spread, 'ore': self.player.ore, 'disk_count': self.player.disk_count,
                'disk_speed': self.player.disk_speed, 'disk_damage': self.player.disk_damage,
                'has_blink': self.player.has_blink, 'has_shockwave': self.player.has_shockwave,
                'relics': self.player.relics, 'selected_relic': self.player.selected_relic, 'has_jet': self.player.has_jet,
                'alt_weapon': self.player.alt_weapon, 'weapon_levels': self.player.weapon_levels,
                'regen_rate': self.player.regen_rate, 'bombs': self.player.bombs, 'pos': [self.player.pos.x, self.player.pos.y],
            }
        }
        RUN_SAVE_FILE.write_text(json.dumps(data, indent=2))
        self.float_texts.append(FloatText('Run saved', self.player.pos.copy(), GREEN))

    # Function or method implementation.
    def load_run(self):
        if not RUN_SAVE_FILE.exists():
            return False
        data = json.loads(RUN_SAVE_FILE.read_text())
        self.profile_index = clamp(int(data.get('profile_index', 0)), 0, 2)
        self.mode_index = MODE_LIST.index(data.get('mode_name', 'Frontier')) if data.get('mode_name', 'Frontier') in MODE_LIST else 0
        self.reset_run(new_run=False)
        p = data['player']
        self.wave = data['wave']
        self.score = data['score']
        self.player.hp = p['hp']
        self.player.max_hp = p['max_hp']
        self.player.speed = p['speed']
        self.player.damage = p['damage']
        self.player.fire_delay = p['fire_delay']
        self.player.projectiles = p['projectiles']
        self.player.spread = p['spread']
        self.player.ore = p['ore']
        self.player.disk_count = p['disk_count']
        self.player.disk_speed = p['disk_speed']
        self.player.disk_damage = p['disk_damage']
        self.player.has_blink = p['has_blink']
        self.player.has_shockwave = p['has_shockwave']
        self.player.relics = p['relics'] if isinstance(p['relics'], dict) else {'heal': int(p['relics']), 'nova': 0, 'burst': 0}
        self.player.selected_relic = p.get('selected_relic', 'heal')
        self.player.has_jet = p.get('has_jet', self.player.has_jet)
        self.player.alt_weapon = p.get('alt_weapon', self.player.alt_weapon)
        self.player.weapon_levels = p.get('weapon_levels', self.player.weapon_levels)
        self.player.regen_rate = p.get('regen_rate', self.player.regen_rate)
        self.player.bombs = p.get('bombs', self.player.bombs)
        self.player.pos = Vector2(p['pos'])
        self.player.ensure_disks()
        self.spawn_wave()
        self.state = 'playing'
        return True

    # Function or method implementation.
    def refresh_stage_music(self, force: bool = False):
        stage = self.current_stage_index()
        if force or stage != getattr(self, 'current_music_stage', -1):
            self.current_music_stage = stage
            track = self.stage_music[min(stage, len(self.stage_music) - 1)]
            self.audio.play_music_track(track)

    def current_stage_index(self):
        return min(3, (max(1, self.wave) - 1) // 10)

    def current_stage_name(self):
        return ['Shard Wastes', 'Verdant Drift', 'Cryo Expanse', 'Ember Rift'][self.current_stage_index()]

    def current_stage_palette(self):
        palettes = [
            {'bg': (11, 16, 24), 'grid': (18, 24, 36), 'overlay': None},
            {'bg': (10, 24, 18), 'grid': (18, 44, 32), 'overlay': (40, 120, 70, 28)},
            {'bg': (12, 18, 34), 'grid': (30, 48, 76), 'overlay': (140, 210, 255, 20)},
            {'bg': (30, 12, 16), 'grid': (62, 26, 32), 'overlay': (255, 110, 60, 16)},
        ]
        return palettes[self.current_stage_index()]

    def current_stage_events(self):
        stage = self.current_stage_index()
        if stage == 0:
            return [CometLineEvent]
        if stage == 1:
            return [VineSnareEvent, WarpAmbushEvent]
        if stage == 2:
            return [FrostNovaEvent, CometLineEvent]
        return [SandSurgeEvent, WarpAmbushEvent, CometLineEvent]

    def maybe_trigger_event(self):
        # Events start only after the early waves so the opening stays readable.
        if self.active_event is not None or self.wave < 2:
            return
        self.event_timer -= 1 / FPS
        if self.event_timer <= 0:
            base_min = max(6.5, 9.5 - self.wave * 0.15)
            base_max = max(10.5, 15.0 - self.wave * 0.2)
            self.event_timer = random.uniform(base_min, base_max) / GAME_MODES[self.mode_name]['event_rate']
            event_cls = random.choice(self.current_stage_events())
            self.active_event = event_cls()
            self.float_texts.append(FloatText(self.active_event.name, self.player.pos.copy(), ORANGE))

    # Function or method implementation.
    def update_pickups(self, dt):
        keep = []
        for p in self.pickups:
            p.ttl -= dt
            delta = self.player.pos - p.pos
            dist = delta.length() if delta.length_squared() else 0
            if dist < self.player.magnet and dist > 0:
                p.pos += delta.normalize() * max(90, 950 / max(15, dist)) * dt
            if dist < self.player.radius + 16:
                if p.kind == 'ore':
                    self.player.ore += p.value
                    self.score += p.value
                    self.float_texts.append(FloatText(f'+{p.value} ore', p.pos.copy(), YELLOW))
                    self.audio.play('eat')
                elif p.kind == 'relic':
                    relic_kind = random.choice(['heal', 'nova', 'burst'])
                    self.player.grant_relic(relic_kind)
                    self.float_texts.append(FloatText(f'{relic_kind.title()} relic', p.pos.copy(), PURPLE))
                    self.audio.play('clear')
                elif p.kind == 'heal':
                    self.player.heal(p.value)
                    self.float_texts.append(FloatText(f'+{p.value} hp', p.pos.copy(), GREEN))
                    self.audio.play('clear')
                elif p.kind == 'shield':
                    self.player.shield += p.value
                    self.float_texts.append(FloatText('Shield up', p.pos.copy(), CYAN))
                    self.audio.play('clear')
                else:
                    self.player.temp_buffs.append(TemporaryBuff(p.kind, 12.0))
                    self.float_texts.append(FloatText(p.kind.title(), p.pos.copy(), ORANGE))
                    if random.random() < 0.22:
                        self.profile.setdefault('stored_buffs', []).append(p.kind)
                        self.profile['stored_buffs'] = self.profile['stored_buffs'][-8:]
                    self.audio.play('clear')
                continue
            if p.ttl > 0:
                keep.append(p)
        self.pickups = keep

    # Function or method implementation.
    def move_bullet_vs_obstacles(self, bullet):
        for obs in self.obstacles:
            if bullet.pos.distance_to(obs.pos) < bullet.radius + obs.radius:
                bullet.alive = False
                if getattr(bullet, 'explosive', False):
                    self.explosions.append(Explosion(bullet.pos, getattr(bullet, 'explosion_radius', 96), bullet.damage, 0.35))
                self.audio.play('wall')
                return True
        return False

    # Function or method implementation.
    def handle_collisions(self):
        for bullet in self.player_bullets:
            if not bullet.alive:
                continue
            if self.move_bullet_vs_obstacles(bullet):
                continue
            for node in self.nodes:
                if node.alive and bullet.pos.distance_to(node.pos) < bullet.radius + node.radius:
                    ore = node.hit(bullet.damage)
                    bullet.pierce -= 1
                    if bullet.pierce < 0:
                        bullet.alive = False
                        if getattr(bullet, 'explosive', False):
                            self.explosions.append(Explosion(bullet.pos, getattr(bullet, 'explosion_radius', 96), bullet.damage, 0.35))
                    if ore:
                        self.spawn_pickups(node.pos, ore)
                        self.audio.play('clear')
                    break
            if not bullet.alive:
                continue
            for pot in self.loot_pots:
                if pot.alive and bullet.pos.distance_to(pot.pos) < bullet.radius + pot.radius:
                    pot.hit(bullet.damage, self)
                    bullet.pierce -= 1
                    if bullet.pierce < 0:
                        bullet.alive = False
                        if getattr(bullet, 'explosive', False):
                            self.explosions.append(Explosion(bullet.pos, getattr(bullet, 'explosion_radius', 96), bullet.damage, 0.35))
                    break
            if not bullet.alive:
                continue
            for enemy in self.enemies:
                if enemy.alive and bullet.pos.distance_to(enemy.pos) < bullet.radius + enemy.radius:
                    enemy.take_hit(bullet.damage, self)
                    bullet.pierce -= 1
                    if bullet.pierce < 0:
                        bullet.alive = False
                        if getattr(bullet, 'explosive', False):
                            self.explosions.append(Explosion(bullet.pos, getattr(bullet, 'explosion_radius', 96), bullet.damage, 0.35))
                    break

        for bullet in self.enemy_bullets:
            if not bullet.alive:
                continue
            if self.move_bullet_vs_obstacles(bullet):
                continue
            if bullet.pos.distance_to(self.player.pos) < bullet.radius + self.player.radius:
                bullet.alive = False
                self.player.hit(bullet.damage, self)

        for obs in self.obstacles:
            delta = self.player.pos - obs.pos
            d = delta.length()
            if d and d < self.player.radius + obs.radius:
                push = delta.normalize() * (self.player.radius + obs.radius - d + 1)
                self.player.pos += push

        self.player_bullets = [b for b in self.player_bullets if b.alive]
        self.enemy_bullets = [b for b in self.enemy_bullets if b.alive]
        self.enemies = [e for e in self.enemies if e.alive]
        self.nodes = [n for n in self.nodes if n.alive]
        self.loot_pots = [pot for pot in self.loot_pots if pot.alive]
        self.particles = [p for p in self.particles if p.ttl > 0]
        self.float_texts = [f for f in self.float_texts if f.ttl > 0]

    # Function or method implementation.
    def apply_shop_item(self, idx):
        # Paid upgrades use their own limit and are not blocked by taking a free pick.
        if self.wave_purchase_count >= self.max_shop_purchases:
            self.float_texts.append(FloatText('Shop limit reached', self.player.pos.copy(), ORANGE))
            return
        if 0 <= idx < len(self.shop_items):
            item = self.shop_items[idx]
            if self.player.ore >= item['cost']:
                self.player.ore -= item['cost']
                self.player.apply_effect(item['key'])
                self.wave_purchase_count += 1
                self.float_texts.append(FloatText(item['name'], self.player.pos.copy(), GREEN))
                self.audio.play('clear')
                del self.shop_items[idx]
                for shop_item in self.shop_items:
                    shop_item['cost'] += 10
            else:
                self.float_texts.append(FloatText('Not enough ore', self.player.pos.copy(), RED))

    # Function or method implementation.
    def apply_freebie(self, idx):
        # Free picks have a separate limit from paid purchases.
        if self.free_pick_count >= self.max_free_picks or not (0 <= idx < len(self.free_choices)):
            return
        _, _, key = self.free_choices[idx]
        self.player.apply_effect(key)
        self.free_pick_count += 1
        self.intermission_pick_done = self.free_pick_count >= self.max_free_picks
        self.float_texts.append(FloatText('Free pick used', self.player.pos.copy(), CYAN))

    # Function or method implementation.
    def finish_run(self):
        self.profile['highscores'][self.mode_name] = max(self.profile['highscores'].get(self.mode_name, 0), self.score)
        self.profile['stored_relics'] = self.player.relics
        self.profile['unlocks']['blink'] = self.profile['unlocks'].get('blink', False) or self.player.has_blink
        self.profile['unlocks']['shockwave'] = self.profile['unlocks'].get('shockwave', False) or self.player.has_shockwave
        self.profile['unlocks']['jetpack'] = self.profile['unlocks'].get('jetpack', False) or self.player.has_jet
        self.profile['unlocks']['alt_weapon'] = self.player.alt_weapon
        self.profile['unlocks']['weapon_levels'] = self.player.weapon_levels
        self.profile['unlocks']['regen_rate'] = self.player.regen_rate
        self.profile['unlocks']['bombs'] = self.player.bombs
        self.profile['stored_buffs'] = self.profile.get('stored_buffs', [])[-8:]
        self.save_profiles()

    # Function or method implementation.
    def update(self, dt):
        if self.state == 'playing':
            keys = pygame.key.get_pressed()
            self.player.update(dt, self, keys)
            for b in self.player_bullets:
                b.update(dt)
            for b in self.enemy_bullets:
                b.update(dt)
            self.laser_beams = [beam for beam in self.laser_beams if beam.update(dt)]
            for e in self.enemies:
                e.update(dt, self)
            for p in self.particles:
                p.update(dt)
            for f in self.float_texts:
                f.update(dt)
            self.explosions = [ex for ex in self.explosions if ex.update(dt, self)]
            if self.active_event and not self.active_event.update(dt, self):
                self.active_event = None
            self.update_pickups(dt)
            self.handle_collisions()
            if self.wave_spawn_remaining > 0:
                self.batch_spawn_timer -= dt
                if self.batch_spawn_timer <= 0 and len(self.enemies) <= 8 + self.wave:
                    batch = min(max(4, 2 + self.wave // 2), self.wave_spawn_remaining)
                    self.spawn_enemy_batch(batch)
                    self.wave_spawn_remaining -= batch
                    self.batch_spawn_timer = max(1.6, 3.4 - self.wave * 0.08)
                    self.float_texts.append(FloatText('Reinforcements!', self.player.pos.copy(), ORANGE))
            self.maybe_trigger_event()
            self.camera.update(self.player.pos)
            if self.player.hp <= 0:
                self.finish_run()
                self.state = 'gameover'
            if not self.enemies and self.wave_spawn_remaining <= 0 and not self.nodes:
                self.stage_clear_delay = 1.2
                self.float_texts.append(FloatText('Stage Clear', self.player.pos.copy(), CYAN))
                self.state = 'stage_clear'
                self.audio.play('clear')
        elif self.state in ('intermission', 'paused'):
            for f in self.float_texts:
                f.update(dt)
            self.float_texts = [f for f in self.float_texts if f.ttl > 0]
        elif self.state == 'stage_clear':
            self.stage_clear_delay -= dt
            for f in self.float_texts:
                f.update(dt)
            self.float_texts = [f for f in self.float_texts if f.ttl > 0]
            if self.stage_clear_delay <= 0:
                self.reroll_shop()
                self.state = 'intermission'
        elif self.state == 'menu':
            self.camera.update(Vector2(WORLD_W/2, WORLD_H/2))

    # Function or method implementation.
    def draw_world(self):
        self.refresh_stage_music()
        palette = self.current_stage_palette()
        self.screen.fill(palette['bg'])
        if getattr(self, 'bg_panorama_sheet', None):
            if not hasattr(self, 'world_backdrop') or self.world_backdrop.get_size() != (WIDTH, HEIGHT):
                self.world_backdrop = pygame.transform.smoothscale(self.bg_panorama_sheet, (WIDTH, HEIGHT))
            self.screen.blit(self.world_backdrop, (0, 0))
            veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            veil.fill((8, 12, 24, 120))
            self.screen.blit(veil, (0, 0))
        star_rng = random.Random(1234)
        for _ in range(120):
            sx = star_rng.randint(0, WIDTH)
            sy = star_rng.randint(0, HEIGHT)
            r = 1 + (star_rng.randint(0, 10) > 8)
            pygame.draw.circle(self.screen, (180, 190, 220), (sx, sy), r)
        grid_step = 120
        for x in range(0, WORLD_W + 1, grid_step):
            a = self.camera.world_to_screen(Vector2(x, 0))
            b = self.camera.world_to_screen(Vector2(x, WORLD_H))
            pygame.draw.line(self.screen, palette['grid'], a, b, 1)
        for y in range(0, WORLD_H + 1, grid_step):
            a = self.camera.world_to_screen(Vector2(0, y))
            b = self.camera.world_to_screen(Vector2(WORLD_W, y))
            pygame.draw.line(self.screen, palette['grid'], a, b, 1)

        for deco in self.decorations:
            p = self.camera.world_to_screen(deco.pos)
            if deco.key in getattr(self, 'object_strips', {}):
                strip = self.object_strips[deco.key]
                img = strip[int(abs(math.sin(deco.bob)) * 1000) % max(1, len(strip))]
            else:
                img = self.assets.get(deco.key, self.assets['deco_terminal'])
            w = max(12, int(img.get_width() * deco.scale * self.camera.zoom))
            h = max(12, int(img.get_height() * deco.scale * self.camera.zoom))
            scaled = pygame.transform.smoothscale(img, (w, h))
            yoff = math.sin(pygame.time.get_ticks() * 0.001 + deco.bob) * (2 if deco.key in getattr(self, 'object_strips', {}) else 4)
            rect = scaled.get_rect(center=(int(p.x), int(p.y + yoff)))
            self.screen.blit(scaled, rect)

        for obs in self.obstacles:
            p = self.camera.world_to_screen(obs.pos)
            style = getattr(obs, 'style', 'obstacle_small' if obs.radius < 40 else 'obstacle')
            img = self.assets.get(style, self.assets['obstacle'])
            scaled = pygame.transform.smoothscale(img, (self.camera.scale_value(img.get_width()), self.camera.scale_value(img.get_height())))
            rect = scaled.get_rect(center=(int(p.x), int(p.y)))
            self.screen.blit(scaled, rect)

        for pot in self.loot_pots:
            p = self.camera.world_to_screen(pot.pos)
            img = self.assets['pot_heal'] if pot.kind == 'heal' else self.assets['pot_buff']
            scaled = pygame.transform.smoothscale(img, (self.camera.scale_value(img.get_width()), self.camera.scale_value(img.get_height())))
            rect = scaled.get_rect(center=(int(p.x), int(p.y + math.sin(pot.phase + pygame.time.get_ticks()*0.005) * 5)))
            self.screen.blit(scaled, rect)

        for node in self.nodes:
            p = self.camera.world_to_screen(node.pos)
            img = self.assets['mystery']
            scaled = pygame.transform.smoothscale(img, (self.camera.scale_value(img.get_width()), self.camera.scale_value(img.get_height())))
            rect = scaled.get_rect(center=(int(p.x), int(p.y)))
            self.screen.blit(scaled, rect)
            pygame.draw.circle(self.screen, PURPLE, rect.center, self.camera.scale_value(node.radius), max(1, self.camera.scale_value(2)))

        for p in self.pickups:
            pos = self.camera.world_to_screen(p.pos)
            if p.kind == 'ore':
                img = self.object_strips['minerals'][0]
            elif p.kind == 'relic':
                img = self.object_strips['items'][0]
            elif p.kind == 'heal':
                img = self.object_strips['items'][1]
            elif p.kind == 'shield':
                img = self.object_strips['items'][2]
            else:
                img = self.object_strips['comets'][min(1, len(self.object_strips['comets'])-1)]
            scaled = pygame.transform.smoothscale(img, (self.camera.scale_value(img.get_width()), self.camera.scale_value(img.get_height())))
            rect = scaled.get_rect(center=(int(pos.x), int(pos.y)))
            self.screen.blit(scaled, rect)

        for b in self.player_bullets + self.enemy_bullets:
            pos = self.camera.world_to_screen(b.pos)
            sprite_key = getattr(b, 'sprite_key', '')
            if sprite_key and sprite_key in getattr(self, 'projectile_sprites', {}):
                frames = self.projectile_sprites[sprite_key]
                img = frames[int(pygame.time.get_ticks() * 0.02) % max(1, len(frames))]
                ang = -Vector2(1, 0).angle_to(b.vel) if b.vel.length_squared() > 0 else 0
                rot = pygame.transform.rotate(img, ang)
                scaled = pygame.transform.smoothscale(
                    rot,
                    (
                        max(4, self.camera.scale_value(rot.get_width() * 0.9)),
                        max(4, self.camera.scale_value(rot.get_height() * 0.9)),
                    ),
                )
                self.screen.blit(scaled, scaled.get_rect(center=(int(pos.x), int(pos.y))))
            else:
                glow_r = max(2, self.camera.scale_value(b.radius * 2))
                pygame.draw.circle(self.screen, b.color, (int(pos.x), int(pos.y)), glow_r, 1)
                pygame.draw.circle(self.screen, b.color, (int(pos.x), int(pos.y)), self.camera.scale_value(b.radius))
        for beam in self.laser_beams:
            a = self.camera.world_to_screen(beam.start)
            b = self.camera.world_to_screen(beam.end)
            pygame.draw.line(self.screen, beam.color, a, b, max(2, self.camera.scale_value(beam.width)))
            if 'beam' in getattr(self, 'projectile_sprites', {}):
                tip = self.projectile_sprites['beam'][-1]
                ang = -Vector2(1, 0).angle_to(beam.end - beam.start)
                rot = pygame.transform.rotate(tip, ang)
                scaled = pygame.transform.smoothscale(rot, (max(6, self.camera.scale_value(rot.get_width())), max(6, self.camera.scale_value(rot.get_height()))))
                self.screen.blit(scaled, scaled.get_rect(center=(int(b.x), int(b.y))))

        for ex in self.explosions:
            pos = self.camera.world_to_screen(ex.pos)
            radius = self.camera.scale_value(ex.radius * (1 - ex.ttl / ex.max_ttl * 0.35))
            fill = pygame.Surface((radius * 2 + 4, radius * 2 + 4), pygame.SRCALPHA)
            pygame.draw.circle(fill, (255, 160, 40, 35), (radius + 2, radius + 2), radius)
            self.screen.blit(fill, (int(pos.x - radius - 2), int(pos.y - radius - 2)))
            pygame.draw.circle(self.screen, ORANGE, (int(pos.x), int(pos.y)), radius, max(1, self.camera.scale_value(4)))

        for e in self.enemies:
            pos = self.camera.world_to_screen(e.pos)
            anim_set = self.enemy_frames.get(getattr(e, 'sprite_kind', e.kind), self.enemy_frames['grunt'])
            if isinstance(anim_set, dict):
                if getattr(e, 'warp_anim', 0.0) > 0 and 'warp' in anim_set:
                    state = 'warp'
                elif getattr(e, 'reappear_anim', 0.0) > 0 and 'reappear' in anim_set:
                    state = 'reappear'
                else:
                    state = 'attack' if getattr(e, 'attack_anim', 0.0) > 0 else 'walk'
                frames = anim_set.get(state) or anim_set.get('walk') or next(iter(anim_set.values()))
            else:
                frames = anim_set
            idx = int(e.anim_time * self.enemy_anim_speed.get(getattr(e, 'sprite_kind', e.kind), 8)) % max(1, len(frames))
            img2 = frames[idx].copy()
            if e.flash > 0:
                img2.fill((255, 255, 255, 90), special_flags=pygame.BLEND_RGBA_ADD)
            boss_mult = 2 if getattr(e, 'is_boss', False) else 1
            scaled = pygame.transform.smoothscale(img2, (self.camera.scale_value(img2.get_width() * boss_mult), self.camera.scale_value(img2.get_height() * boss_mult)))
            rect = scaled.get_rect(center=(int(pos.x), int(pos.y)))
            self.screen.blit(scaled, rect)
            if e.kind == 'bomber':
                fuse_ratio = clamp(e.arm_timer / 2.2, 0, 1)
                pygame.draw.circle(self.screen, RED, rect.center, self.camera.scale_value(5 + 8 * (1-fuse_ratio)), max(1, self.camera.scale_value(2)))

        for part in self.particles:
            pos = self.camera.world_to_screen(part.pos)
            pygame.draw.circle(self.screen, part.color, (int(pos.x), int(pos.y)), self.camera.scale_value(max(1, int(part.radius))))

        self.draw_player()

        trail = tuple(self.profile['skin']['trail_tint'])
        for disk in self.player.disks:
            dp = self.camera.world_to_screen(disk.position())
            pygame.draw.circle(self.screen, trail, (int(dp.x), int(dp.y)), self.camera.scale_value(10))
            pygame.draw.circle(self.screen, WHITE, (int(dp.x), int(dp.y)), self.camera.scale_value(10), max(1, self.camera.scale_value(2)))

        if palette.get('overlay'):
            veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            veil.fill(palette['overlay'])
            self.screen.blit(veil, (0, 0))

        if self.active_event:
            self.active_event.draw(self.screen, self)

        for f in self.float_texts:
            pos = self.camera.world_to_screen(f.pos)
            img = self.font_sm.render(f.text, True, f.color)
            self.screen.blit(img, img.get_rect(center=(pos.x, pos.y)))

    # Function or method implementation.
    def current_player_frame(self) -> pygame.Surface:
        if self.state == 'gameover' or self.player.hp <= 0:
            state = 'dead'
        elif self.player.invuln > 0.08:
            state = 'hurt'
        elif self.player.dash_cd > 0.82:
            state = 'jetpack'
        elif self.player.is_shooting:
            state = 'shoot'
        elif self.player.vel.length_squared() > 1:
            state = 'run'
        else:
            state = 'idle'
        frames = self.player_frames[state]
        idx = int(self.player.anim_time * (10 if state in ('run', 'jetpack') else 7)) % len(frames)
        frame = frames[idx]
        if not self.player.facing_right:
            frame = pygame.transform.flip(frame, True, False)
        tint = tuple(self.profile['skin']['ship_tint'])
        return tint_surface(frame, tint)

    # Function or method implementation.
    def draw_player(self):
        frame = self.current_player_frame()
        scaled = pygame.transform.smoothscale(frame, (self.camera.scale_value(frame.get_width()), self.camera.scale_value(frame.get_height())))
        p = self.camera.world_to_screen(self.player.pos)
        rect = scaled.get_rect(center=(int(p.x), int(p.y)))
        self.screen.blit(scaled, rect)

    # Function or method implementation.
    def blit_generated_panel(self, rect: pygame.Rect, title: str | None = None, accent=CYAN, alt_title: bool = False):
        bg = pygame.transform.smoothscale(self.ui_generated['panel'], rect.size)
        self.screen.blit(bg, rect)
        tint = pygame.Surface(rect.size, pygame.SRCALPHA)
        tint.fill((6, 14, 28, 86))
        self.screen.blit(tint, rect)
        pygame.draw.rect(self.screen, accent, rect, 2, border_radius=18)
        if self.ui_parts.get('corner'):
            c = pygame.transform.smoothscale(self.ui_parts['corner'], (36, 36))
            self.screen.blit(c, (rect.x - 4, rect.y - 4))
        if self.ui_parts.get('corner2'):
            c2 = pygame.transform.smoothscale(self.ui_parts['corner2'], (40, 24))
            self.screen.blit(c2, (rect.right - 36, rect.y - 2))
        if self.ui_parts.get('corner3'):
            c3 = pygame.transform.smoothscale(self.ui_parts['corner3'], (40, 24))
            self.screen.blit(c3, (rect.x - 4, rect.bottom - 20))
        if title:
            hdr_h = 34 if rect.height < 120 else 42
            hdr = pygame.Rect(rect.x + 12, rect.y + 8, rect.width - 24, hdr_h)
            key = 'header_alt' if alt_title else 'header'
            head = pygame.transform.smoothscale(self.ui_generated[key], hdr.size)
            self.screen.blit(head, hdr)
            label = self.font_md.render(title, True, WHITE)
            self.screen.blit(label, label.get_rect(center=hdr.center))

    def blit_generated_button(self, rect: pygame.Rect, text_label: str, hovered: bool = False, active: bool = False, green: bool = False):
        key = 'button' if rect.width >= 260 else 'button_small'
        img = pygame.transform.smoothscale(self.ui_generated[key], rect.size)
        self.screen.blit(img, rect)

        pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() * 0.006)
        if green:
            glow = pygame.Surface(rect.size, pygame.SRCALPHA)
            glow.fill((50, 170, 80, 70 if hovered else 30 + int(20 * pulse)))
            self.screen.blit(glow, rect)
        elif hovered:
            glow = pygame.Surface(rect.size, pygame.SRCALPHA)
            glow.fill((70, 140, 255, 55))
            self.screen.blit(glow, rect)
        elif active:
            glow = pygame.Surface(rect.size, pygame.SRCALPHA)
            glow.fill((220, 170, 50, 28))
            self.screen.blit(glow, rect)

        border = WHITE if hovered else (YELLOW if active else CYAN)
        pygame.draw.rect(self.screen, border, rect, 2, border_radius=12)

        shadow = self.font_md.render(text_label, True, (0, 0, 0))
        label = self.font_md.render(text_label, True, YELLOW if active else WHITE)
        self.screen.blit(shadow, shadow.get_rect(center=(rect.centerx + 1, rect.centery + 1)))
        self.screen.blit(label, label.get_rect(center=rect.center))

    def draw_ui(self):
        left = pygame.Rect(10, 10, 455, 160)
        right = pygame.Rect(WIDTH - 310, 10, 300, 216)
        bottom = pygame.Rect(10, HEIGHT - 108, 560, 98)
        self.blit_generated_panel(left, 'Status', CYAN)
        self.blit_generated_panel(right, 'Run Data', PURPLE)
        self.blit_generated_panel(bottom, 'Supplies', GREEN, alt_title=True)

        hp_ratio = clamp(self.player.hp / max(1, self.player.max_hp), 0, 1)
        sh_ratio = clamp(self.player.shield / 5.0, 0, 1)

        if self.ui_parts.get('hpbar'):
            bar = pygame.transform.smoothscale(self.ui_parts['hpbar'], (320, 34))
            self.screen.blit(bar, (left.x + 92, left.y + 48))
        else:
            pygame.draw.rect(self.screen, (16, 24, 42), (left.x + 92, left.y + 50, 240, 16), border_radius=8)
        if self.ui_parts.get('shieldbar'):
            sbar = pygame.transform.smoothscale(self.ui_parts['shieldbar'], (320, 30))
            self.screen.blit(sbar, (left.x + 92, left.y + 88))
        else:
            pygame.draw.rect(self.screen, (16, 24, 42), (left.x + 92, left.y + 90, 240, 12), border_radius=6)

        pygame.draw.rect(self.screen, RED, (left.x + 112, left.y + 60, int(250 * hp_ratio), 10), border_radius=5)
        pygame.draw.rect(self.screen, CYAN, (left.x + 112, left.y + 98, int(250 * sh_ratio), 8), border_radius=4)

        self.screen.blit(self.font_sm.render('HP', True, TEXT), (left.x + 24, left.y + 56))
        self.screen.blit(self.font_sm.render('Shield', True, TEXT), (left.x + 24, left.y + 94))
        self.screen.blit(self.font_sm.render(f'{int(self.player.hp)}/{self.player.max_hp}', True, WHITE), (left.x + 356, left.y + 54))
        self.screen.blit(self.font_sm.render(str(int(self.player.shield * 24)), True, WHITE), (left.x + 356, left.y + 90))

        if self.ui_parts.get('left') and self.ui_parts.get('center') and self.ui_parts.get('right'):
            l = pygame.transform.smoothscale(self.ui_parts['left'], (60, 24))
            c = pygame.transform.smoothscale(self.ui_parts['center'], (120, 24))
            r = pygame.transform.smoothscale(self.ui_parts['right'], (60, 24))
            base_y = left.y + 126
            self.screen.blit(l, (left.x + 14, base_y))
            self.screen.blit(c, (left.x + 70, base_y))
            self.screen.blit(r, (left.x + 190, base_y))
            self.screen.blit(self.font_sm.render(f'Wave {self.wave}', True, YELLOW), (left.x + 34, base_y + 2))
            self.screen.blit(self.font_sm.render(f'Score {self.score}', True, GREEN), (left.x + 218, base_y + 2))
            self.screen.blit(self.font_sm.render(f'DMG {self.player.damage}', True, ORANGE), (left.x + 320, base_y + 2))
        else:
            self.screen.blit(self.font_sm.render(f'Wave {self.wave}', True, YELLOW), (left.x + 22, left.y + 126))
            self.screen.blit(self.font_sm.render(f'Score {self.score}', True, GREEN), (left.x + 130, left.y + 126))
            self.screen.blit(self.font_sm.render(f'DMG {self.player.damage}', True, ORANGE), (left.x + 280, left.y + 126))

        alt = self.player.current_alt_weapon()
        alt_text = 'None' if alt == 'none' else f'{alt.title()} Lv {self.player.weapon_levels.get(alt, 1)}'
        event_name = self.active_event.name if self.active_event else ('Locked until Wave 2' if self.wave < 2 else 'None')
        lines = [
            (f'Mode {self.mode_name}', CYAN),
            (f'Stage {self.current_stage_name()}', CYAN),
            (f'Profile {self.profile_index + 1}: {self.profile["name"]}', TEXT),
            (f'Highscore {self.profile["highscores"].get(self.mode_name, 0)}', MUTED),
            (f'Alt {alt_text}', WHITE),
            (f'Event {event_name}', ORANGE if self.active_event else MUTED),
        ]
        yy = right.y + 54
        for line, color in lines:
            draw_wrapped_text(self.screen, line, self.font_sm, color, pygame.Rect(right.x + 18, yy, right.width - 36, 30), 2)
            yy += 24

        if self.ui_parts.get('icon1'):
            i1 = pygame.transform.smoothscale(self.ui_parts['icon1'], (28, 28))
            self.screen.blit(i1, (bottom.x + 18, bottom.y + 52))
        if self.ui_parts.get('icon2'):
            i2 = pygame.transform.smoothscale(self.ui_parts['icon2'], (28, 28))
            self.screen.blit(i2, (bottom.x + 130, bottom.y + 52))
        self.screen.blit(self.font_sm.render(f'Ore {self.player.ore}', True, YELLOW), (bottom.x + 52, bottom.y + 56))
        self.screen.blit(self.font_sm.render(f'Bombs {self.player.bombs}', True, WHITE), (bottom.x + 164, bottom.y + 56))

        slots = [self.ui_parts.get('slot1'), self.ui_parts.get('slot2'), self.ui_parts.get('slot3')]
        relics = [('heal', GREEN), ('nova', CYAN), ('burst', PURPLE)]
        for i, ((kind, col), slot_img) in enumerate(zip(relics, slots)):
            r = pygame.Rect(bottom.x + 280 + i * 92, bottom.y + 48, 82, 36)
            if slot_img:
                slot = pygame.transform.smoothscale(slot_img, r.size)
                self.screen.blit(slot, r)
            else:
                pygame.draw.rect(self.screen, (10, 18, 34), r, border_radius=8)
            pygame.draw.rect(self.screen, WHITE if self.player.selected_relic == kind else col, r, 2, border_radius=8)
            txt = self.font_sm.render(f'{kind[:1].upper()}:{self.player.relics.get(kind, 0)}', True, TEXT)
            self.screen.blit(txt, txt.get_rect(center=r.center))

        bosses = [en for en in self.enemies if getattr(en, 'is_boss', False) and en.alive]
        for i, boss in enumerate(bosses[:4]):
            bw, bh = 300, 14
            rx, ry = WIDTH // 2 - bw // 2, 96 + i * 20
            self.blit_generated_panel(pygame.Rect(rx - 8, ry - 20, bw + 16, 34), None, RED)
            pygame.draw.rect(self.screen, (18, 28, 56), (rx, ry, bw, bh), border_radius=6)
            ratio = clamp(boss.hp / max(1, getattr(boss, 'max_hp', boss.hp)), 0, 1)
            pygame.draw.rect(self.screen, RED, (rx, ry, int(bw * ratio), bh), border_radius=6)
            self.screen.blit(self.font_sm.render(getattr(boss, 'name', 'Boss'), True, WHITE), (rx + 8, ry - 16))

    # Function or method implementation.
    def draw_minimap(self):
        rect = pygame.Rect(WIDTH - 250, HEIGHT - 250, 220, 220)
        if self.ui_parts.get('map'):
            frame = pygame.transform.smoothscale(self.ui_parts['map'], rect.size)
            self.screen.blit(frame, rect)
            inner = pygame.Rect(rect.x + 18, rect.y + 18, rect.width - 36, rect.height - 36)
        else:
            pygame.draw.rect(self.screen, PANEL, rect, border_radius=14)
            pygame.draw.rect(self.screen, WHITE, rect, 2, border_radius=14)
            inner = rect
        sx = inner.width / WORLD_W
        sy = inner.height / WORLD_H
        for obs in self.obstacles:
            pygame.draw.circle(self.screen, MUTED, (int(inner.x + obs.pos.x * sx), int(inner.y + obs.pos.y * sy)), 2)
        for pot in self.loot_pots:
            color = GREEN if pot.kind == 'heal' else CYAN
            pygame.draw.circle(self.screen, color, (int(inner.x + pot.pos.x * sx), int(inner.y + pot.pos.y * sy)), 2)
        for node in self.nodes:
            pygame.draw.circle(self.screen, PURPLE, (int(inner.x + node.pos.x * sx), int(inner.y + node.pos.y * sy)), 2)
        for enemy in self.enemies:
            pygame.draw.circle(self.screen, RED, (int(inner.x + enemy.pos.x * sx), int(inner.y + enemy.pos.y * sy)), 2)
        pygame.draw.circle(self.screen, CYAN, (int(inner.x + self.player.pos.x * sx), int(inner.y + self.player.pos.y * sy)), 3)

    # Function or method implementation.
    def draw_menu(self):
        if self.generated_ui_bg is not None:
            bg = pygame.transform.smoothscale(self.generated_ui_bg, (WIDTH, HEIGHT))
            self.screen.blit(bg, (0, 0))
        else:
            self.screen.fill(BG)
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((6, 10, 22, 95))
        self.screen.blit(veil, (0, 0))

        mouse = pygame.mouse.get_pos()
        self.menu_rects = {}
        self.submenu_rects = {}

        pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() * 0.004)
        title_top = pygame.transform.smoothscale(self.ui_generated['header_alt'], (860, 92))
        title_bottom = pygame.transform.smoothscale(self.ui_generated['header'], (760, 74))
        top_rect = title_top.get_rect(center=(WIDTH // 2, 58))
        bottom_rect = title_bottom.get_rect(center=(WIDTH // 2, 110))
        self.screen.blit(title_top, top_rect)
        self.screen.blit(title_bottom, bottom_rect)

        glow_color = (
            int(90 + 80 * pulse),
            int(200 + 40 * pulse),
            255,
        )
        title_shadow = self.font_xl.render(TITLE, True, (0, 0, 0))
        title_glow = self.font_xl.render(TITLE, True, glow_color)
        title_main = self.font_xl.render(TITLE, True, WHITE)

        self.screen.blit(title_shadow, title_shadow.get_rect(center=(WIDTH // 2 + 4, 102)))
        self.screen.blit(title_glow, title_glow.get_rect(center=(WIDTH // 2 + 2, 100)))
        self.screen.blit(title_main, title_main.get_rect(center=(WIDTH // 2, 98)))

        subtitle = self.font_sm.render('Shard the void. Survive the frontier.', True, GREEN)
        self.screen.blit(subtitle, subtitle.get_rect(center=(WIDTH // 2, 142)))

        panel = pygame.Rect(WIDTH // 2 - 250, 156, 500, 500)
        self.blit_generated_panel(panel, None, CYAN)

        labels = ['Start Run', 'Load Saved Run', f'Mode: {self.mode_name}', 'Settings', 'Controls', 'Customize', 'Quit']
        keys = ['Start Run', 'Load Saved Run', 'Mode', 'Settings', 'Controls', 'Customize', 'Quit']
        y = panel.y + 34
        for label_text, key in zip(labels, keys):
            rect = pygame.Rect(panel.x + 72, y, panel.width - 144, 46)
            hovered = rect.collidepoint(mouse)
            active = key == self.menu_section
            self.blit_generated_button(rect, label_text, hovered, active, green=(key == 'Start Run'))
            self.menu_rects[key] = rect
            y += 58

        if self.menu_section in ('Settings', 'Controls', 'Customize'):
            body = pygame.Rect(panel.x + 32, panel.bottom - 164, panel.width - 64, 130)
            self.blit_generated_panel(body, self.menu_section, PURPLE)
            inner = body.inflate(-16, -42)
            if self.menu_section == 'Settings':
                items = [('Profile Slot', str(self.profile_index + 1)), ('Window Size', f'{WIDTH}x{HEIGHT}'), ('SFX Volume', f'{int(self.sfx_volume * 100)}%'), ('Music Volume', f'{int(self.music_volume * 100)}%')]
                yy = inner.y
                for key, value in items:
                    r = pygame.Rect(inner.x, yy, inner.width, 24)
                    hovered = r.collidepoint(mouse)
                    pygame.draw.rect(self.screen, (12,24,44) if not hovered else (18,34,62), r, border_radius=8)
                    pygame.draw.rect(self.screen, CYAN, r, 1, border_radius=8)
                    self.screen.blit(self.font_sm.render(key, True, TEXT), (r.x + 8, r.y + 3))
                    self.screen.blit(self.font_sm.render(value + '  < >', True, CYAN), (r.right - 110, r.y + 3))
                    self.submenu_rects[key] = r
                    yy += 28
            elif self.menu_section == 'Controls':
                yy = inner.y
                for line in ['WASD / Arrows Move', 'LMB Primary fire', 'RMB Alt arsenal', 'Space Dash', 'Q Blink', 'Shift Jet', 'E Use relic', 'G Bomb', 'P / Esc Pause']:
                    self.screen.blit(self.font_sm.render(line, True, TEXT), (inner.x + 4, yy))
                    yy += 14
            elif self.menu_section == 'Customize':
                yy = inner.y
                for key, value in [('Ship Tint', str(tuple(self.profile['skin']['ship_tint']))), ('Trail Tint', str(tuple(self.profile['skin']['trail_tint'])))]:
                    r = pygame.Rect(inner.x, yy, inner.width, 28)
                    hovered = r.collidepoint(mouse)
                    pygame.draw.rect(self.screen, (12,24,44) if not hovered else (18,34,62), r, border_radius=8)
                    pygame.draw.rect(self.screen, CYAN, r, 1, border_radius=8)
                    self.screen.blit(self.font_sm.render(key, True, TEXT), (r.x + 8, r.y + 5))
                    self.screen.blit(self.font_sm.render(value + '  < >', True, CYAN), (r.right - 170, r.y + 5))
                    self.submenu_rects[key] = r
                    yy += 34

    # Function or method implementation.
    def draw_intermission(self):
        self.draw_world()
        self.draw_ui()
        mouse = pygame.mouse.get_pos()
        self.shop_free_rects = []
        self.shop_item_rects = []

        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 170))
        self.screen.blit(veil, (0, 0))

        panel = pygame.Rect(WIDTH // 2 - 520, 24, 1040, HEIGHT - 48)
        self.blit_generated_panel(panel, 'Stage Clear Shop', CYAN, alt_title=True)
        self.screen.blit(self.font_md.render(f'Ore: {self.player.ore}', True, YELLOW), (panel.right - 150, panel.y + 18))

        free_w, free_h = 300, 140
        free_gap = 22
        fx = panel.centerx - (free_w * 3 + free_gap * 2) // 2
        fy = panel.y + 74
        self.screen.blit(self.font_md.render(f'Free Picks {self.free_pick_count}/{self.max_free_picks}', True, CYAN), (panel.x + 24, fy - 28))
        for i, (name, desc, _) in enumerate(self.free_choices):
            rect = pygame.Rect(fx + i * (free_w + free_gap), fy, free_w, free_h)
            hovered = rect.collidepoint(mouse)
            available = self.free_pick_count < self.max_free_picks
            self.blit_generated_button(rect, name, hovered and available, False, green=available)
            body = pygame.Rect(rect.x + 16, rect.y + 48, rect.width - 32, rect.height - 62)
            draw_wrapped_text(self.screen, desc, self.font_sm, MUTED, body, 2)
            self.shop_free_rects.append(rect)

        items = self.shop_items
        iw, ih = 230, 160
        ig = 18
        ix = panel.centerx - (iw * max(1, len(items)) + ig * max(0, len(items) - 1)) // 2
        iy = fy + free_h + 36
        self.screen.blit(self.font_md.render('Shop', True, YELLOW), (panel.x + 24, iy - 30))
        for i, item in enumerate(items):
            rect = pygame.Rect(ix + i * (iw + ig), iy, iw, ih)
            hovered = rect.collidepoint(mouse)
            self.blit_generated_panel(rect, None, YELLOW if hovered else CYAN)
            self.screen.blit(self.font_md.render(item['name'], True, TEXT), (rect.x + 14, rect.y + 12))
            draw_wrapped_text(self.screen, item['desc'], self.font_sm, MUTED, pygame.Rect(rect.x + 14, rect.y + 48, rect.width - 28, 60), 2)
            cost_rect = pygame.Rect(rect.x + 12, rect.bottom - 40, 110, 28)
            pygame.draw.rect(self.screen, (14, 24, 44), cost_rect, border_radius=8)
            pygame.draw.rect(self.screen, GREEN, cost_rect, 2, border_radius=8)
            self.screen.blit(self.font_md.render(str(item['cost']), True, YELLOW), (cost_rect.x + 24, cost_rect.y + 2))
            self.shop_item_rects.append(rect)

        self.shop_refresh_rect = pygame.Rect(panel.centerx - 240, panel.bottom - 58, 210, 44)
        self.shop_next_rect = pygame.Rect(panel.centerx + 30, panel.bottom - 58, 210, 44)
        self.blit_generated_button(self.shop_refresh_rect, f'Refresh ({self.shop_refreshes})', self.shop_refresh_rect.collidepoint(mouse), False, False)
        self.blit_generated_button(self.shop_next_rect, 'Next Stage', self.shop_next_rect.collidepoint(mouse), False, True)

    # Function or method implementation.
    def handle_pause_click(self, pos):
        if not hasattr(self, 'pause_rects'):
            return
        if self.pause_rects.get('resume', pygame.Rect(0, 0, 0, 0)).collidepoint(pos):
            self.state = 'playing'
        elif self.pause_rects.get('save_run', pygame.Rect(0, 0, 0, 0)).collidepoint(pos):
            self.save_run()
        elif self.pause_rects.get('save_profile', pygame.Rect(0, 0, 0, 0)).collidepoint(pos):
            self.finish_run()
        elif self.pause_rects.get('return_menu', pygame.Rect(0, 0, 0, 0)).collidepoint(pos):
            self.state = 'menu'

    def draw_pause(self):
        self.draw_world()
        self.draw_ui()
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 170))
        self.screen.blit(veil, (0, 0))

        mouse = pygame.mouse.get_pos()
        self.pause_rects = {}
        panel = pygame.Rect(WIDTH // 2 - 250, HEIGHT // 2 - 170, 500, 340)
        self.blit_generated_panel(panel, 'Paused', CYAN, alt_title=True)

        items = [('Resume', 'resume', True), ('Save Run', 'save_run', False), ('Save Profile', 'save_profile', False), ('Return to Menu', 'return_menu', False)]
        y = panel.y + 74
        for label, key, green in items:
            rect = pygame.Rect(panel.x + 80, y, panel.width - 160, 44)
            hovered = rect.collidepoint(mouse)
            self.blit_generated_button(rect, label, hovered, False, green)
            self.pause_rects[key] = rect
            y += 56

        hint_lines = ['P / Esc Resume', 'F5 Save run', 'F9 Save profile', 'M Return to menu']
        yy = panel.bottom - 80
        caption = self.font_sm.render('Quick Actions', True, GREEN)
        self.screen.blit(caption, caption.get_rect(center=(panel.centerx, yy)))
        yy += 18
        for line in hint_lines:
            txt = self.font_sm.render(line, True, CYAN)
            self.screen.blit(txt, txt.get_rect(center=(panel.centerx, yy)))
            yy += 14

    # Function or method implementation.
    def draw_gameover(self):
        self.draw_world()
        self.draw_ui()
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((0,0,0,185))
        self.screen.blit(veil, (0,0))
        t = self.font_lg.render('Run Lost', True, TEXT)
        self.screen.blit(t, t.get_rect(center=(WIDTH/2, 180)))
        lines = [f'Final score: {self.score}', f'Wave reached: {self.wave}', f'Highscore in {self.mode_name}: {self.profile["highscores"].get(self.mode_name, 0)}', 'Press R to retry or Enter for menu']
        y = 270
        for line in lines:
            img = self.font_md.render(line, True, YELLOW if 'score' in line.lower() else TEXT)
            self.screen.blit(img, img.get_rect(center=(WIDTH/2, y)))
            y += 48

    # Function or method implementation.
    def draw(self):
        if self.state == 'menu':
            self.draw_menu()
            return
        self.draw_world()
        self.draw_ui()
        if self.player.combo > 1:
            combo_text = self.font_md.render(f'Combo x{self.player.combo}', True, YELLOW)
            self.screen.blit(combo_text, combo_text.get_rect(midtop=(WIDTH // 2, 12)))
        keys = pygame.key.get_pressed()
        if keys[pygame.K_TAB]:
            self.draw_minimap()
        if self.state == 'intermission':
            self.draw_intermission()
        elif self.state == 'stage_clear':
            msg = self.font_lg.render('STAGE CLEAR', True, CYAN)
            self.screen.blit(msg, msg.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
        elif self.state == 'paused':
            self.draw_pause()
        elif self.state == 'gameover':
            self.draw_gameover()

        if self.damage_flash > 0:
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((255, 40, 40, int(110 * self.damage_flash / 0.16)))
            self.screen.blit(overlay, (0, 0))
        if self.heal_flash > 0:
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((40, 255, 120, int(80 * self.heal_flash / 0.12)))
            self.screen.blit(overlay, (0, 0))

    # Function or method implementation.
    def activate_menu_item(self, item):
        if item == 'Start Run':
            self.reset_run(new_run=True)
            self.state = 'playing'
        elif item == 'Load Saved Run':
            self.load_run()
        elif item == 'Mode':
            self.adjust_menu_item('Mode', 1)
        elif item in ('Settings', 'Controls', 'Customize'):
            self.menu_section = None if self.menu_section == item else item
        elif item == 'Quit':
            return False
        return True

    # Function or method implementation.
    def adjust_menu_item(self, item, dirv):
        if item == 'Profile Slot':
            self.profile_index = (self.profile_index + dirv) % 3
        elif item == 'Mode':
            self.mode_index = (self.mode_index + dirv) % len(MODE_LIST)
        elif item == 'Ship Tint':
            self.tint_index = (self.tint_index + dirv) % len(self.colors)
            self.profile['skin']['ship_tint'] = list(self.colors[self.tint_index])
            self.save_profiles()
        elif item == 'Trail Tint':
            self.trail_index = (self.trail_index + dirv) % len(self.colors)
            self.profile['skin']['trail_tint'] = list(self.colors[self.trail_index])
            self.save_profiles()
        elif item == 'Window Size':
            current = (WIDTH, HEIGHT)
            idx = self.window_sizes.index(current) if current in self.window_sizes else 1
            idx = (idx + dirv) % len(self.window_sizes)
            self.apply_window_size(self.window_sizes[idx])
        elif item == 'SFX Volume':
            self.sfx_volume = clamp(round(self.sfx_volume + dirv * 0.05, 2), 0.0, 1.0)
            self.apply_audio_settings()
        elif item == 'Music Volume':
            self.music_volume = clamp(round(self.music_volume + dirv * 0.05, 2), 0.0, 1.0)
            self.apply_audio_settings()
        elif item == 'UI Scale':
            self.ui_scale = clamp(round(self.ui_scale + dirv * 0.1, 2), 0.8, 1.6)
            self.apply_ui_settings()
            self.save_settings()
        elif item == 'Text Size':
            self.text_size = int(clamp(self.text_size + dirv * 10, 80, 150))
            self.apply_ui_settings()
            self.save_settings()

    # Function or method implementation.
    def handle_menu_click(self, pos):
        for i, item in enumerate(self.menu_items):
            rect = self.menu_rects.get(item)
            if rect and rect.collidepoint(pos):
                self.menu_index = i
                return self.activate_menu_item(item)
        for key, rect in self.submenu_rects.items():
            if rect.collidepoint(pos):
                self.adjust_menu_item(key, 1)
                return True
        return True

    # Function or method implementation.
    def handle_intermission_click(self, pos):
        for i, rect in enumerate(self.shop_free_rects):
            if rect.collidepoint(pos):
                self.apply_freebie(i)
                return
        for i, rect in enumerate(self.shop_item_rects):
            if rect.collidepoint(pos):
                self.apply_shop_item(i)
                return
        if self.shop_refresh_rect.collidepoint(pos):
            self.refresh_shop()
            return
        if self.shop_next_rect.collidepoint(pos):
            self.wave += 1
            self.spawn_wave()
            self.state = 'playing'

    # Function or method implementation.
    def handle_menu_key(self, key):
        if key == pygame.K_UP:
            self.menu_index = (self.menu_index - 1) % len(self.menu_items)
        elif key == pygame.K_DOWN:
            self.menu_index = (self.menu_index + 1) % len(self.menu_items)
        elif key in (pygame.K_LEFT, pygame.K_RIGHT):
            self.adjust_menu_item(self.menu_items[self.menu_index], -1 if key == pygame.K_LEFT else 1)
        elif key == pygame.K_RETURN:
            return self.activate_menu_item(self.menu_items[self.menu_index])
        return True

    # Function or method implementation.
    def run(self):
        running = True
        while running:
            dt = self.clock.tick(FPS) / 1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEWHEEL:
                    if self.state in ('playing', 'intermission', 'paused', 'gameover'):
                        self.camera.change_zoom(event.y * 0.12)
                elif event.type == pygame.VIDEORESIZE:
                    globals()['WIDTH'], globals()['HEIGHT'] = max(960, event.w), max(540, event.h)
                    self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
                    self.save_settings()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if self.state == 'menu':
                        keep = self.handle_menu_click(event.pos)
                        if keep is False:
                            running = False
                    elif self.state == 'intermission':
                        self.handle_intermission_click(event.pos)
                    elif self.state == 'paused':
                        self.handle_pause_click(event.pos)
                    elif self.state == 'stage_clear':
                        pass
                elif event.type == pygame.KEYDOWN:
                    if self.state == 'menu':
                        keep = self.handle_menu_key(event.key)
                        if keep is False or event.key == pygame.K_ESCAPE:
                            running = False
                    elif self.state == 'playing':
                        if event.key in (pygame.K_LEFTBRACKET, pygame.K_MINUS):
                            self.camera.change_zoom(-0.12)
                        elif event.key in (pygame.K_RIGHTBRACKET, pygame.K_EQUALS, pygame.K_PLUS):
                            self.camera.change_zoom(0.12)
                        elif event.key in (pygame.K_p, pygame.K_ESCAPE):
                            self.state = 'paused'
                        elif event.key == pygame.K_e:
                            self.player.use_relic(self)
                        elif event.key == pygame.K_1:
                            self.player.select_relic('heal')
                        elif event.key == pygame.K_2:
                            self.player.select_relic('nova')
                        elif event.key == pygame.K_3:
                            self.player.select_relic('burst')
                        elif event.key == pygame.K_b:
                            stored = self.profile.get('stored_buffs', [])
                            if stored:
                                self.player.temp_buffs.append(TemporaryBuff(stored.pop(), 12.0))
                                self.save_profiles()
                                self.float_texts.append(FloatText('Stored Buff', self.player.pos.copy(), CYAN))
                        elif event.key == pygame.K_g and self.player.bombs > 0:
                            self.player.bombs -= 1
                            self.explosions.append(Explosion(self.player.pos.copy(), 150 + self.wave // 3, 42 + self.wave // 2, 0.38))
                            self.float_texts.append(FloatText('Bomb!', self.player.pos.copy(), ORANGE))
                            self.audio.play('weapon_explosion')
                        elif event.key == pygame.K_F5:
                            self.save_run()
                        elif event.key == pygame.K_F9:
                            self.finish_run()
                    elif self.state == 'paused':
                        if event.key in (pygame.K_LEFTBRACKET, pygame.K_MINUS):
                            self.camera.change_zoom(-0.12)
                        elif event.key in (pygame.K_RIGHTBRACKET, pygame.K_EQUALS, pygame.K_PLUS):
                            self.camera.change_zoom(0.12)
                        elif event.key in (pygame.K_p, pygame.K_ESCAPE):
                            self.state = 'playing'
                        elif event.key == pygame.K_F5:
                            self.save_run()
                        elif event.key == pygame.K_F9:
                            self.finish_run()
                        elif event.key == pygame.K_m:
                            self.finish_run()
                            self.state = 'menu'
                    elif self.state == 'intermission':
                        if event.key in (pygame.K_LEFTBRACKET, pygame.K_MINUS):
                            self.camera.change_zoom(-0.12)
                        elif event.key in (pygame.K_RIGHTBRACKET, pygame.K_EQUALS, pygame.K_PLUS):
                            self.camera.change_zoom(0.12)
                        elif event.key in (pygame.K_1, pygame.K_KP1):
                            self.apply_freebie(0)
                        elif event.key in (pygame.K_2, pygame.K_KP2):
                            self.apply_freebie(1)
                        elif event.key in (pygame.K_3, pygame.K_KP3):
                            self.apply_freebie(2)
                        elif event.key in (pygame.K_4, pygame.K_KP4):
                            self.apply_shop_item(0)
                        elif event.key in (pygame.K_5, pygame.K_KP5):
                            self.apply_shop_item(1)
                        elif event.key in (pygame.K_6, pygame.K_KP6):
                            self.apply_shop_item(2)
                        elif event.key in (pygame.K_7, pygame.K_KP7):
                            self.apply_shop_item(3)
                        elif event.key == pygame.K_r:
                            self.refresh_shop()
                        elif event.key == pygame.K_n:
                            self.wave += 1
                            self.spawn_wave()
                            self.state = 'playing'
                    elif self.state == 'gameover':
                        if event.key == pygame.K_r:
                            self.reset_run(new_run=True)
                            self.state = 'playing'
                        elif event.key == pygame.K_RETURN:
                            self.state = 'menu'
            self.update(dt)
            self.draw()
            pygame.display.flip()
        pygame.quit()


if __name__ == '__main__':
    Game().run()
