\
@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv 2>nul
    if errorlevel 1 python -m venv .venv
)
call ".venv\Scripts\python.exe" -m pip install --upgrade pip
call ".venv\Scripts\python.exe" -m pip install pyinstaller -r requirements.txt
call ".venv\Scripts\pyinstaller.exe" --noconfirm --windowed --onefile --name "Shardfall Frontier v29" main.py
pause
