
import pygame, sys, random

pygame.init()
screen = pygame.display.set_mode((800,600))
clock = pygame.time.Clock()

player = pygame.Rect(100,500,40,40)
enemies = [pygame.Rect(random.randint(200,700),500,40,40) for _ in range(5)]
bullets = []

running=True
while running:
    dt = clock.tick(60)/1000
    for e in pygame.event.get():
        if e.type==pygame.QUIT:
            running=False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]: player.x -= 200*dt
    if keys[pygame.K_d]: player.x += 200*dt

    if pygame.mouse.get_pressed()[0]:
        bullets.append(pygame.Rect(player.x+20,player.y,10,10))

    for b in bullets:
        b.x += 400*dt

    for e in enemies:
        if random.random()<0.01:
            e.x += random.choice([-20,20])

    for b in bullets:
        for e in enemies:
            if b.colliderect(e):
                enemies.remove(e)

    screen.fill((20,20,40))
    pygame.draw.rect(screen,(0,200,255),player)
    for e in enemies:
        pygame.draw.rect(screen,(255,80,80),e)
    for b in bullets:
        pygame.draw.rect(screen,(255,255,0),b)

    pygame.display.flip()

pygame.quit()
sys.exit()
