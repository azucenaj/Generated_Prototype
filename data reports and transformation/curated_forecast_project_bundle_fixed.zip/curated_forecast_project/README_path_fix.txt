Use dashboard_builder_portable.py instead of the old dashboard_builder.py.
It resolves CSV files relative to the extracted folder, so it works on Windows after unzip.
