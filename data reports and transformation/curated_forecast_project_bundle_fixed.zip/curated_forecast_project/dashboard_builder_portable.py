
from pathlib import Path
import pandas as pd

# Resolve paths in a portable way:
# 1) Prefer files beside this script in the same extracted folder
# 2) Fallback to a sibling folder named "curated_forecast_project"
SCRIPT_DIR = Path(__file__).resolve().parent
CANDIDATES = [
    SCRIPT_DIR,
    SCRIPT_DIR / "curated_forecast_project",
    SCRIPT_DIR.parent / "curated_forecast_project",
]

def find_file(filename: str) -> Path:
    for folder in CANDIDATES:
        path = folder / filename
        if path.exists():
            return path
    raise FileNotFoundError(
        f"Could not find {filename}. Tried: " + ", ".join(str(folder / filename) for folder in CANDIDATES)
    )

out_dir = find_file('dataset_catalog.csv').parent

catalog = pd.read_csv(find_file('dataset_catalog.csv'))
benchmark = pd.read_csv(find_file('gld_model_benchmark.csv'))
preds = pd.read_csv(find_file('gld_test_predictions.csv'))
forecast = pd.read_csv(find_file('gld_30_business_day_forecast.csv'))

html = f"""
<html>
<head>
    <meta charset="utf-8"/>
    <title>Curated Forecast Dashboard</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 24px; line-height: 1.45; }}
        h1, h2 {{ margin-bottom: 0.3rem; }}
        .card {{ border: 1px solid #ddd; border-radius: 10px; padding: 16px; margin: 14px 0; }}
        table {{ border-collapse: collapse; width: 100%; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background: #f5f5f5; }}
        code {{ background: #f6f8fa; padding: 2px 6px; border-radius: 6px; }}
    </style>
</head>
<body>
    <h1>Curated Forecast Dashboard</h1>
    <p>Resolved data folder: <code>{out_dir}</code></p>

    <div class="card">
        <h2>Dataset Catalog</h2>
        {catalog.head(20).to_html(index=False)}
    </div>

    <div class="card">
        <h2>Model Benchmark</h2>
        {benchmark.to_html(index=False)}
    </div>

    <div class="card">
        <h2>Backtest Predictions</h2>
        {preds.head(30).to_html(index=False)}
    </div>

    <div class="card">
        <h2>30 Business Day Forecast</h2>
        {forecast.to_html(index=False)}
    </div>
</body>
</html>
"""

output_file = SCRIPT_DIR / 'curated_forecast_dashboard.html'
output_file.write_text(html, encoding='utf-8')
print(f"Dashboard written to: {output_file}")
